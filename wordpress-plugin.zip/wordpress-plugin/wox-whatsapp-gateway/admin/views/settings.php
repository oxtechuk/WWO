<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>

<div class="wrap wox-admin-wrap">
    <h1>⚙️ <?php esc_html_e( 'إعدادات بوابة Wox للواتساب', 'wox-whatsapp' ); ?></h1>
    <p class="subtitle"><?php esc_html_e( 'تعديل تفاصيل الاتصال، مفاتيح API وخيارات التنبيهات العامة.', 'wox-whatsapp' ); ?></p>

    <form method="post" action="options.php" class="wox-settings-form">
        <?php
        settings_fields( 'wox_settings_group' );
        do_settings_sections( 'wox_settings_group' );
        ?>

        <div class="wox-form-section">
            <h2>🔑 <?php esc_html_e( 'بيانات الربط مع بوابة Wox', 'wox-whatsapp' ); ?></h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="wox_server_url"><?php esc_html_e( 'رابط سيرفر Wox API', 'wox-whatsapp' ); ?></label></th>
                    <td>
                        <input name="wox_server_url" type="url" id="wox_server_url" value="<?php echo esc_attr( get_option( 'wox_server_url', 'http://localhost:8080' ) ); ?>" class="regular-text" />
                        <p class="description"><?php esc_html_e( 'رابط الـ Gateway (مثال: http://localhost:8080 أو https://api.wox.yourdomain.com)', 'wox-whatsapp' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="wox_global_api_key"><?php esc_html_e( 'مفتاح API العام (Global API Key)', 'wox-whatsapp' ); ?></label></th>
                    <td>
                        <input name="wox_global_api_key" type="password" id="wox_global_api_key" value="<?php echo esc_attr( get_option( 'wox_global_api_key' ) ); ?>" class="regular-text" />
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="wox_instance_name"><?php esc_html_e( 'اسم مثيل الواتساب (Instance)', 'wox-whatsapp' ); ?></label></th>
                    <td>
                        <input name="wox_instance_name" type="text" id="wox_instance_name" value="<?php echo esc_attr( get_option( 'wox_instance_name', 'wox_store' ) ); ?>" class="regular-text" />
                    </td>
                </tr>
            </table>
        </div>

        <div class="wox-form-section">
            <h2>🏢 <?php esc_html_e( 'الحساب والاشتراك المركزي (موقعنا)', 'wox-whatsapp' ); ?></h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="wox_account_id"><?php esc_html_e( 'معرف الحساب (Account ID)', 'wox-whatsapp' ); ?></label></th>
                    <td>
                        <input name="wox_account_id" type="text" id="wox_account_id" value="<?php echo esc_attr( get_option( 'wox_account_id' ) ); ?>" class="regular-text" />
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="wox_license_key"><?php esc_html_e( 'مفتاح الترخيص (License Key)', 'wox-whatsapp' ); ?></label></th>
                    <td>
                        <input name="wox_license_key" type="text" id="wox_license_key" value="<?php echo esc_attr( get_option( 'wox_license_key' ) ); ?>" class="regular-text" />
                    </td>
                </tr>
            </table>
        </div>

        <div class="wox-form-section">
            <h2>📱 <?php esc_html_e( 'أرقام الهواتف وإشعارات البريد', 'wox-whatsapp' ); ?></h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="wox_admin_phone"><?php esc_html_e( 'رقم هاتف المدير لتلقي الإشعارات', 'wox-whatsapp' ); ?></label></th>
                    <td>
                        <input name="wox_admin_phone" type="text" id="wox_admin_phone" value="<?php echo esc_attr( get_option( 'wox_admin_phone' ) ); ?>" class="regular-text" />
                        <p class="description"><?php esc_html_e( 'الرقم الذي ستصل إليه تنبيهات الطلبات الجديدة وإشعارات النظام.', 'wox-whatsapp' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="wox_country_prefix"><?php esc_html_e( 'مفتاح الدولة الافتراضي', 'wox-whatsapp' ); ?></label></th>
                    <td>
                        <input name="wox_country_prefix" type="text" id="wox_country_prefix" value="<?php echo esc_attr( get_option( 'wox_country_prefix', '+20' ) ); ?>" class="small-text" />
                        <p class="description"><?php esc_html_e( 'يضاف تلقائياً إذا أدخل العميل الرقم بدون مفتاح دولي (مثال: +20 لمصر أو +966 للسعودية).', 'wox-whatsapp' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e( 'تكامل بريد ووردبريس (WP Mail)', 'wox-whatsapp' ); ?></th>
                    <td>
                        <label>
                            <input name="wox_enable_wp_mail" type="checkbox" value="yes" <?php checked( get_option( 'wox_enable_wp_mail', 'yes' ), 'yes' ); ?> />
                            <?php esc_html_e( 'تفعيل إرسال إشعارات ووردبريس عبر الواتساب', 'wox-whatsapp' ); ?>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="wox_wp_mail_mode"><?php esc_html_e( 'نمط تكامل WP Mail', 'wox-whatsapp' ); ?></label></th>
                    <td>
                        <select name="wox_wp_mail_mode" id="wox_wp_mail_mode">
                            <option value="mirror" <?php selected( get_option( 'wox_wp_mail_mode', 'mirror' ), 'mirror' ); ?>>
                                <?php esc_html_e( 'إرسال متوازي (واتساب + بريد إلكتروني)', 'wox-whatsapp' ); ?>
                            </option>
                            <option value="replace" <?php selected( get_option( 'wox_wp_mail_mode' ), 'replace' ); ?>>
                                <?php esc_html_e( 'استبدال كامل (واتساب فقط وإيقاف البريد)', 'wox-whatsapp' ); ?>
                            </option>
                        </select>
                    </td>
                </tr>
            </table>
        </div>

        <?php submit_button( __( 'حفظ كافة الإعدادات', 'wox-whatsapp' ) ); ?>
    </form>
</div>
