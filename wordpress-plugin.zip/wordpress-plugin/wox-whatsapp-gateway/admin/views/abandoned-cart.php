<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$recovery_rate = ( $total_abandoned > 0 ) ? round( ( $total_recovered / ( $total_abandoned + $total_recovered ) ) * 100, 1 ) : 0;
?>

<div class="wrap wox-admin-wrap">
    <h1>🛒 <?php esc_html_e( 'استرجاع السلات المتروكة عبر الواتساب', 'wox-whatsapp' ); ?></h1>
    <p class="subtitle"><?php esc_html_e( 'متابعة وإعادة استهداف العملاء الذين بدأوا الشراء ولم يكملوا الدفع.', 'wox-whatsapp' ); ?></p>

    <!-- Metrics -->
    <div class="wox-stats-cards">
        <div class="wox-stat-card">
            <div class="stat-icon">🛒</div>
            <div class="stat-content">
                <div class="stat-val"><?php echo intval( $total_abandoned ); ?></div>
                <div class="stat-title"><?php esc_html_e( 'سلات متروكة حالياً', 'wox-whatsapp' ); ?></div>
            </div>
        </div>
        <div class="wox-stat-card success">
            <div class="stat-icon">💰</div>
            <div class="stat-content">
                <div class="stat-val"><?php echo intval( $total_recovered ); ?></div>
                <div class="stat-title"><?php esc_html_e( 'سلات تم استرجاعها بنجاح', 'wox-whatsapp' ); ?></div>
            </div>
        </div>
        <div class="wox-stat-card">
            <div class="stat-icon">📈</div>
            <div class="stat-content">
                <div class="stat-val"><?php echo esc_html( $recovery_rate ); ?>%</div>
                <div class="stat-title"><?php esc_html_e( 'نسبة الاسترجاع', 'wox-whatsapp' ); ?></div>
            </div>
        </div>
        <div class="wox-stat-card plan">
            <div class="stat-icon">💵</div>
            <div class="stat-content">
                <div class="stat-val"><?php echo wc_price( $recovered_revenue ); ?></div>
                <div class="stat-title"><?php esc_html_e( 'قيمة المبيعات المسترجعة', 'wox-whatsapp' ); ?></div>
            </div>
        </div>
    </div>

    <!-- Abandoned Carts Table -->
    <div class="wox-table-section">
        <h2>📋 <?php esc_html_e( 'أحدث السلات المسجلة', 'wox-whatsapp' ); ?></h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'العميل', 'wox-whatsapp' ); ?></th>
                    <th><?php esc_html_e( 'الهاتف', 'wox-whatsapp' ); ?></th>
                    <th><?php esc_html_e( 'إجمالي السلة', 'wox-whatsapp' ); ?></th>
                    <th><?php esc_html_e( 'الحالة', 'wox-whatsapp' ); ?></th>
                    <th><?php esc_html_e( 'تذكيرات أُرسلت', 'wox-whatsapp' ); ?></th>
                    <th><?php esc_html_e( 'تاريخ التسجيل', 'wox-whatsapp' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if ( empty( $carts ) ) : ?>
                    <tr>
                        <td colspan="6" style="text-align:center; padding:20px;">
                            <?php esc_html_e( 'لا توجد سلات مسجلة حتى الآن.', 'wox-whatsapp' ); ?>
                        </td>
                    </tr>
                <?php else : ?>
                    <?php foreach ( $carts as $c ) : 
                        $status_badge = ( $c->status === 'recovered' ) ? 'badge-success' : ( ( $c->status === 'abandoned' ) ? 'badge-warning' : 'badge-neutral' );
                    ?>
                        <tr>
                            <td><strong><?php echo esc_html( ! empty( $c->customer_name ) ? $c->customer_name : __( 'زائر', 'wox-whatsapp' ) ); ?></strong></td>
                            <td><code><?php echo esc_html( $c->phone ); ?></code></td>
                            <td><?php echo wc_price( $c->cart_total, array( 'currency' => $c->currency ) ); ?></td>
                            <td><span class="wox-badge <?php echo esc_attr( $status_badge ); ?>"><?php echo esc_html( ucfirst( $c->status ) ); ?></span></td>
                            <td><?php echo intval( $c->reminders_sent ); ?> / 2</td>
                            <td><?php echo esc_html( $c->created_at ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <hr style="margin:40px 0; border:0; border-top:1px solid #cbd5e1;" />

    <!-- Configuration Form -->
    <form method="post" action="options.php" class="wox-settings-form">
        <?php
        settings_fields( 'wox_cart_group' );
        do_settings_sections( 'wox_cart_group' );
        ?>

        <div class="wox-form-section">
            <h2>⚙️ <?php esc_html_e( 'إعدادات توقيت تذكيرات السلة', 'wox-whatsapp' ); ?></h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><?php esc_html_e( 'تفعيل ميزة استرجاع السلات', 'wox-whatsapp' ); ?></th>
                    <td>
                        <label>
                            <input name="wox_enable_abandoned_cart" type="checkbox" value="yes" <?php checked( get_option( 'wox_enable_abandoned_cart', 'yes' ), 'yes' ); ?> />
                            <?php esc_html_e( 'تشغيل التتبع والإرسال التلقائي للواتساب', 'wox-whatsapp' ); ?>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="wox_cart_abandoned_cut_off"><?php esc_html_e( 'مدة اعتبار السلة متروكة (بالدقائق)', 'wox-whatsapp' ); ?></label></th>
                    <td>
                        <input name="wox_cart_abandoned_cut_off" type="number" id="wox_cart_abandoned_cut_off" value="<?php echo esc_attr( get_option( 'wox_cart_abandoned_cut_off', 45 ) ); ?>" class="small-text" />
                        <span class="description"><?php esc_html_e( 'إذا توقف العميل هذه المدة دون دفع، تُصنف السلة كمتروكة.', 'wox-whatsapp' ); ?></span>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="wox_cart_reminder_1_delay"><?php esc_html_e( 'موعد إرسال التذكير الأول (بالدقائق)', 'wox-whatsapp' ); ?></label></th>
                    <td>
                        <input name="wox_cart_reminder_1_delay" type="number" id="wox_cart_reminder_1_delay" value="<?php echo esc_attr( get_option( 'wox_cart_reminder_1_delay', 60 ) ); ?>" class="small-text" />
                        <span class="description"><?php esc_html_e( 'مثال: 60 دقيقة بعد ترك السلة.', 'wox-whatsapp' ); ?></span>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="wox_cart_reminder_2_delay"><?php esc_html_e( 'موعد إرسال التذكير الثاني (بالدقائق)', 'wox-whatsapp' ); ?></label></th>
                    <td>
                        <input name="wox_cart_reminder_2_delay" type="number" id="wox_cart_reminder_2_delay" value="<?php echo esc_attr( get_option( 'wox_cart_reminder_2_delay', 1440 ) ); ?>" class="small-text" />
                        <span class="description"><?php esc_html_e( 'مثال: 1440 دقيقة (24 ساعة) بعد ترك السلة.', 'wox-whatsapp' ); ?></span>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="wox_cart_coupon_code"><?php esc_html_e( 'كوبون الخصم التحفيزي', 'wox-whatsapp' ); ?></label></th>
                    <td>
                        <input name="wox_cart_coupon_code" type="text" id="wox_cart_coupon_code" value="<?php echo esc_attr( get_option( 'wox_cart_coupon_code', 'SAVE10' ) ); ?>" class="regular-text" />
                        <p class="description"><?php esc_html_e( 'كود كوبون منشأ في ووكومرس يظهر في رسالة التذكير الثانية {coupon_code}', 'wox-whatsapp' ); ?></p>
                    </td>
                </tr>
            </table>
        </div>

        <div class="wox-form-section">
            <h2>✍️ <?php esc_html_e( 'قوالب رسائل تذكير السلة', 'wox-whatsapp' ); ?></h2>
            <div class="wox-form-group">
                <label><strong><?php esc_html_e( 'نص التذكير الأول (تذكير لطيف):', 'wox-whatsapp' ); ?></strong></label>
                <textarea name="wox_tpl_cart_reminder_1" rows="5" class="large-text"><?php echo esc_textarea( Wox_Templates::get_template( 'cart_reminder_1' ) ); ?></textarea>
            </div>
            <div class="wox-form-group">
                <label><strong><?php esc_html_e( 'نص التذكير الثاني (مع كود الخصم):', 'wox-whatsapp' ); ?></strong></label>
                <textarea name="wox_tpl_cart_reminder_2" rows="5" class="large-text"><?php echo esc_textarea( Wox_Templates::get_template( 'cart_reminder_2' ) ); ?></textarea>
            </div>
        </div>

        <?php submit_button( __( 'حفظ إعدادات السلات المتروكة', 'wox-whatsapp' ) ); ?>
    </form>
</div>
