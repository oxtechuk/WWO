<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>

<div class="wrap wox-admin-wrap">
    <h1>🛍️ <?php esc_html_e( 'إشعارات طلبات ووكومرس عبر الواتساب', 'wox-whatsapp' ); ?></h1>
    <p class="subtitle"><?php esc_html_e( 'تخصيص الرسائل التلقائية التي تصل للعملاء والمدير حسب تغيير حالة الطلب.', 'wox-whatsapp' ); ?></p>

    <!-- Placeholders helper banner -->
    <div class="wox-variables-banner">
        <strong>📌 <?php esc_html_e( 'المتغيرات المتاحة للاستخدام في نصوص الرسائل:', 'wox-whatsapp' ); ?></strong>
        <div class="tags-cloud">
            <code>{customer_name}</code>
            <code>{order_id}</code>
            <code>{order_total}</code>
            <code>{order_status}</code>
            <code>{order_items}</code>
            <code>{payment_method}</code>
            <code>{shipping_address}</code>
            <code>{site_name}</code>
            <code>{admin_order_url}</code>
            <code>{order_view_url}</code>
        </div>
    </div>

    <form method="post" action="options.php" class="wox-settings-form">
        <?php
        settings_fields( 'wox_wc_group' );
        do_settings_sections( 'wox_wc_group' );
        ?>

        <!-- Admin Notification -->
        <div class="wox-form-section">
            <h2>🔔 <?php esc_html_e( 'تنبيه المدير بالطلبات الجديدة', 'wox-whatsapp' ); ?></h2>
            <p>
                <label>
                    <input name="wox_wc_notify_admin" type="checkbox" value="yes" <?php checked( get_option( 'wox_wc_notify_admin', 'yes' ), 'yes' ); ?> />
                    <strong><?php esc_html_e( 'إرسال رسالة واتساب لرقم المدير عند ورود أي طلب جديد', 'wox-whatsapp' ); ?></strong>
                </label>
            </p>
            <div class="wox-form-group">
                <label><?php esc_html_e( 'قالب رسالة المدير:', 'wox-whatsapp' ); ?></label>
                <textarea name="wox_tpl_wc_admin_new_order" rows="5" class="large-text code"><?php echo esc_textarea( Wox_Templates::get_template( 'wc_admin_new_order' ) ); ?></textarea>
            </div>
        </div>

        <!-- Order Status: Pending -->
        <div class="wox-form-section">
            <h2>⏳ <?php esc_html_e( 'الطلب قيد الانتظار (Pending / On-Hold)', 'wox-whatsapp' ); ?></h2>
            <p>
                <label>
                    <input name="wox_wc_status_pending" type="checkbox" value="yes" <?php checked( get_option( 'wox_wc_status_pending', 'yes' ), 'yes' ); ?> />
                    <?php esc_html_e( 'إشعار العميل عند إنشاء الطلب وبانتظار التأكيد/الدفع', 'wox-whatsapp' ); ?>
                </label>
            </p>
            <div class="wox-form-group">
                <textarea name="wox_tpl_wc_status_pending" rows="4" class="large-text"><?php echo esc_textarea( Wox_Templates::get_template( 'wc_status_pending' ) ); ?></textarea>
            </div>
        </div>

        <!-- Order Status: Processing -->
        <div class="wox-form-section">
            <h2>📦 <?php esc_html_e( 'الطلب قيد التجهيز (Processing)', 'wox-whatsapp' ); ?></h2>
            <p>
                <label>
                    <input name="wox_wc_status_processing" type="checkbox" value="yes" <?php checked( get_option( 'wox_wc_status_processing', 'yes' ), 'yes' ); ?> />
                    <?php esc_html_e( 'إشعار العميل عند بدء تجهيز الطلب في المستودع', 'wox-whatsapp' ); ?>
                </label>
            </p>
            <div class="wox-form-group">
                <textarea name="wox_tpl_wc_status_processing" rows="4" class="large-text"><?php echo esc_textarea( Wox_Templates::get_template( 'wc_status_processing' ) ); ?></textarea>
            </div>
        </div>

        <!-- Order Status: Completed -->
        <div class="wox-form-section">
            <h2>🎉 <?php esc_html_e( 'الطلب مكتمل ومسلم (Completed)', 'wox-whatsapp' ); ?></h2>
            <p>
                <label>
                    <input name="wox_wc_status_completed" type="checkbox" value="yes" <?php checked( get_option( 'wox_wc_status_completed', 'yes' ), 'yes' ); ?> />
                    <?php esc_html_e( 'إشعار العميل عند اكتمال الطلب والتسليم', 'wox-whatsapp' ); ?>
                </label>
            </p>
            <div class="wox-form-group">
                <textarea name="wox_tpl_wc_status_completed" rows="4" class="large-text"><?php echo esc_textarea( Wox_Templates::get_template( 'wc_status_completed' ) ); ?></textarea>
            </div>
        </div>

        <!-- Order Status: Cancelled -->
        <div class="wox-form-section">
            <h2>❌ <?php esc_html_e( 'الطلب ملغي (Cancelled)', 'wox-whatsapp' ); ?></h2>
            <p>
                <label>
                    <input name="wox_wc_status_cancelled" type="checkbox" value="yes" <?php checked( get_option( 'wox_wc_status_cancelled', 'yes' ), 'yes' ); ?> />
                    <?php esc_html_e( 'إشعار العميل عند إلغاء الطلب', 'wox-whatsapp' ); ?>
                </label>
            </p>
            <div class="wox-form-group">
                <textarea name="wox_tpl_wc_status_cancelled" rows="4" class="large-text"><?php echo esc_textarea( Wox_Templates::get_template( 'wc_status_cancelled' ) ); ?></textarea>
            </div>
        </div>

        <!-- Order Status: Refunded -->
        <div class="wox-form-section">
            <h2>💰 <?php esc_html_e( 'الطلب مسترجع (Refunded)', 'wox-whatsapp' ); ?></h2>
            <p>
                <label>
                    <input name="wox_wc_status_refunded" type="checkbox" value="yes" <?php checked( get_option( 'wox_wc_status_refunded', 'yes' ), 'yes' ); ?> />
                    <?php esc_html_e( 'إشعار العميل باسترجاع قيمة الطلب', 'wox-whatsapp' ); ?>
                </label>
            </p>
            <div class="wox-form-group">
                <textarea name="wox_tpl_wc_status_refunded" rows="4" class="large-text"><?php echo esc_textarea( Wox_Templates::get_template( 'wc_status_refunded' ) ); ?></textarea>
            </div>
        </div>

        <?php submit_button( __( 'حفظ قوالب ووكومرس', 'wox-whatsapp' ) ); ?>
    </form>
</div>
