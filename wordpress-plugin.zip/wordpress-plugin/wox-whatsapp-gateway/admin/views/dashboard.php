<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$state_class = ( ( $state['state'] ?? '' ) === 'open' ) ? 'connected' : 'disconnected';
$state_label = ( ( $state['state'] ?? '' ) === 'open' ) ? __( 'متصل ونشط', 'wox-whatsapp' ) : __( 'غير متصل', 'wox-whatsapp' );
$instance_name = get_option( 'wox_instance_name', 'wox_store' );
$plan = get_option( 'wox_plan_type', 'standard' );
?>

<div class="wrap wox-admin-wrap">
    <div class="wox-admin-header">
        <div>
            <h1>💬 Wox WhatsApp Gateway</h1>
            <p class="subtitle"><?php esc_html_e( 'لوحة التحكم وحالة الاتصال المباشر بالبوابة', 'wox-whatsapp' ); ?></p>
        </div>
        <div class="header-actions">
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=wox-setup-wizard' ) ); ?>" class="button button-secondary">
                ⚙️ <?php esc_html_e( 'تشغيل معالج الإعداد (Wizard)', 'wox-whatsapp' ); ?>
            </a>
        </div>
    </div>

    <!-- Status Bar -->
    <div class="wox-status-banner <?php echo esc_attr( $state_class ); ?>">
        <div class="status-indicator">
            <span class="status-dot"></span>
            <strong><?php esc_html_e( 'حالة الواتساب:', 'wox-whatsapp' ); ?></strong>
            <span class="status-text"><?php echo esc_html( $state_label ); ?></span>
            <small>(<?php echo esc_html( $instance_name ); ?>)</small>
        </div>
        <div class="status-actions">
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=wox-setup-wizard' ) ); ?>" class="button button-small">
                <?php esc_html_e( 'إعادة المسح / QR Code', 'wox-whatsapp' ); ?>
            </a>
        </div>
    </div>

    <!-- Stats Grid -->
    <div class="wox-stats-cards">
        <div class="wox-stat-card">
            <div class="stat-icon">📨</div>
            <div class="stat-content">
                <div class="stat-val"><?php echo esc_html( $stats['total'] ); ?></div>
                <div class="stat-title"><?php esc_html_e( 'إجمالي الرسائل المرسلة', 'wox-whatsapp' ); ?></div>
            </div>
        </div>
        <div class="wox-stat-card success">
            <div class="stat-icon">✅</div>
            <div class="stat-content">
                <div class="stat-val"><?php echo esc_html( $stats['sent'] ); ?></div>
                <div class="stat-title"><?php esc_html_e( 'تم التسليم بنجاح', 'wox-whatsapp' ); ?></div>
            </div>
        </div>
        <div class="wox-stat-card danger">
            <div class="stat-icon">⚠️</div>
            <div class="stat-content">
                <div class="stat-val"><?php echo esc_html( $stats['failed'] ); ?></div>
                <div class="stat-title"><?php esc_html_e( 'فشل الإرسال', 'wox-whatsapp' ); ?></div>
            </div>
        </div>
        <div class="wox-stat-card plan">
            <div class="stat-icon">👑</div>
            <div class="stat-content">
                <div class="stat-val" style="text-transform:uppercase;"><?php echo esc_html( $plan ); ?></div>
                <div class="stat-title"><?php esc_html_e( 'خطة اشتراك Wox', 'wox-whatsapp' ); ?></div>
            </div>
        </div>
    </div>

    <!-- Quick Links Grid -->
    <div class="wox-cards-grid">
        <div class="wox-card-box">
            <h3>🛍️ <?php esc_html_e( 'إشعارات ووكومرس', 'wox-whatsapp' ); ?></h3>
            <p><?php esc_html_e( 'تخصيص نصوص وقوالب رسائل الطلبات (جاري التجهيز، مكتمل، ملغي) والتنبيهات الموجهة لمدير المتجر والعملاء.', 'wox-whatsapp' ); ?></p>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=wox-woocommerce' ) ); ?>" class="button button-primary">
                <?php esc_html_e( 'إدارة قوالب الطلبات', 'wox-whatsapp' ); ?> ➜
            </a>
        </div>

        <div class="wox-card-box">
            <h3>🛒 <?php esc_html_e( 'السلات المتروكة', 'wox-whatsapp' ); ?></h3>
            <p><?php esc_html_e( 'متابعة العملاء الذين تركوا سلاتهم دون إتمام الشراء، وجدولة تذكيرات آلية مع كوبونات خصم لزيادة المبيعات.', 'wox-whatsapp' ); ?></p>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=wox-abandoned-carts' ) ); ?>" class="button button-primary">
                <?php esc_html_e( 'تقرير واسترجاع السلات', 'wox-whatsapp' ); ?> ➜
            </a>
        </div>

        <div class="wox-card-box">
            <h3>📋 <?php esc_html_e( 'سجل الرسائل والأخطاء', 'wox-whatsapp' ); ?></h3>
            <p><?php esc_html_e( 'الاطلاع على كافة الرسائل الصادرة وحالات التسليم اللحظية مع إمكانية إعادة إرسال الرسائل الفاشلة.', 'wox-whatsapp' ); ?></p>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=wox-logs' ) ); ?>" class="button button-secondary">
                <?php esc_html_e( 'عرض السجلات', 'wox-whatsapp' ); ?> ➜
            </a>
        </div>
    </div>
</div>
