<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$instance_name  = get_option( 'wox_instance_name', 'wox_store_' . wp_generate_password( 6, false ) );
$account_id     = get_option( 'wox_account_id', '' );
$license_key    = get_option( 'wox_license_key', '' );
$server_url     = get_option( 'wox_server_url', 'http://localhost:8080' );
$api_key        = get_option( 'wox_global_api_key', '' );
$admin_phone    = get_option( 'wox_admin_phone', '' );
$country_prefix = get_option( 'wox_country_prefix', '+20' );
$enable_wp_mail = get_option( 'wox_enable_wp_mail', 'yes' );
$enable_wc      = get_option( 'wox_enable_wc', 'yes' );
$enable_cart    = get_option( 'wox_enable_abandoned_cart', 'yes' );
?>

<div class="wox-wizard-wrap">
    <div class="wox-wizard-header">
        <div class="wox-logo-badge">
            <span class="wox-logo-icon">💬</span>
            <span class="wox-logo-text">Wox WhatsApp</span>
        </div>
        <h2><?php esc_html_e( 'معالج إعداد وربط بوابة Wox للواتساب', 'wox-whatsapp' ); ?></h2>
        <p><?php esc_html_e( 'قم بربط متجرك مع منصة Wox في خطوات بسيطة لتفعيل إشعارات الطلبات واسترجاع السلات المتروكة.', 'wox-whatsapp' ); ?></p>
    </div>

    <!-- Stepper Navigation -->
    <div class="wox-stepper">
        <div class="step-item active" data-step="1">
            <div class="step-circle">1</div>
            <div class="step-label"><?php esc_html_e( 'الحساب والاشتراك', 'wox-whatsapp' ); ?></div>
        </div>
        <div class="step-connector"></div>
        <div class="step-item" data-step="2">
            <div class="step-circle">2</div>
            <div class="step-label"><?php esc_html_e( 'ربط الواتساب (QR)', 'wox-whatsapp' ); ?></div>
        </div>
        <div class="step-connector"></div>
        <div class="step-item" data-step="3">
            <div class="step-circle">3</div>
            <div class="step-label"><?php esc_html_e( 'اختيار الموديولات', 'wox-whatsapp' ); ?></div>
        </div>
        <div class="step-connector"></div>
        <div class="step-item" data-step="4">
            <div class="step-circle">4</div>
            <div class="step-label"><?php esc_html_e( 'اختبار وإطلاق', 'wox-whatsapp' ); ?></div>
        </div>
    </div>

    <div class="wox-card">
        <!-- STEP 1: ACCOUNT & SUBSCRIPTION -->
        <div class="wox-step-pane active" id="step-1">
            <h3><?php esc_html_e( 'الخطوة 1: ربط الحساب والاشتراك بـ Wox', 'wox-whatsapp' ); ?></h3>
            <p class="description">
                <?php esc_html_e( 'أدخل معرف الحساب ومفتاح الترخيص الخاص بك في منصة Wox. إذا لم تكن مسجلاً بعد، يمكنك الضغط على تسجيل حساب جديد.', 'wox-whatsapp' ); ?>
            </p>

            <div class="wox-form-group">
                <label for="wox_account_id"><?php esc_html_e( 'معرّف الحساب (Account ID) *', 'wox-whatsapp' ); ?></label>
                <input type="text" id="wox_account_id" class="wox-input" value="<?php echo esc_attr( $account_id ); ?>" placeholder="e.g. ACC-982341" required />
            </div>

            <div class="wox-form-group">
                <label for="wox_license_key"><?php esc_html_e( 'مفتاح الترخيص / الاشتراك (License Key)', 'wox-whatsapp' ); ?></label>
                <input type="text" id="wox_license_key" class="wox-input" value="<?php echo esc_attr( $license_key ); ?>" placeholder="e.g. WOX-PRO-XXXX-XXXX" />
            </div>

            <div class="wox-form-row">
                <div class="wox-form-group half">
                    <label for="wox_server_url"><?php esc_html_e( 'رابط سيرفر Wox Gateway API', 'wox-whatsapp' ); ?></label>
                    <input type="url" id="wox_server_url" class="wox-input" value="<?php echo esc_attr( $server_url ); ?>" placeholder="http://localhost:8080" />
                </div>
                <div class="wox-form-group half">
                    <label for="wox_api_key"><?php esc_html_e( 'مفتاح API العام (Global API Key)', 'wox-whatsapp' ); ?></label>
                    <input type="password" id="wox_api_key" class="wox-input" value="<?php echo esc_attr( $api_key ); ?>" placeholder="e.g. 429683C4C977415CAAFCCE10F7D57E11" />
                </div>
            </div>

            <div class="wox-cta-row">
                <a href="https://oxtech.com/register" target="_blank" class="wox-btn-secondary">
                    <?php esc_html_e( 'ليس لديك حساب؟ اشترك الآن ↗', 'wox-whatsapp' ); ?>
                </a>
                <button type="button" class="wox-btn-primary" id="btn-step-1-next">
                    <?php esc_html_e( 'التحقق والمتابعة ➜', 'wox-whatsapp' ); ?>
                </button>
            </div>
            <div id="step-1-msg" class="wox-notice" style="display:none;"></div>
        </div>

        <!-- STEP 2: INSTANCE & QR CODE -->
        <div class="wox-step-pane" id="step-2" style="display:none;">
            <h3><?php esc_html_e( 'الخطوة 2: مسح كود QR وربط الواتساب', 'wox-whatsapp' ); ?></h3>
            <p class="description">
                <?php esc_html_e( 'افتح تطبيق واتساب في هاتفك > الأجهزة المرتبطة > مسح الرمز المربع لربط رقم المتجر.', 'wox-whatsapp' ); ?>
            </p>

            <div class="wox-form-group">
                <label for="wox_instance_name"><?php esc_html_e( 'اسم مثيل الواتساب (Instance Name)', 'wox-whatsapp' ); ?></label>
                <input type="text" id="wox_instance_name" class="wox-input" value="<?php echo esc_attr( $instance_name ); ?>" />
            </div>

            <div class="wox-qr-container">
                <div id="qr-loading" class="wox-spinner-box">
                    <div class="wox-spinner"></div>
                    <p><?php esc_html_e( 'جاري إنشاء الاتصال وتوليد QR Code...', 'wox-whatsapp' ); ?></p>
                </div>
                <div id="qr-display" style="display:none;">
                    <img id="wox-qr-img" src="" alt="WhatsApp QR Code" />
                    <div class="pairing-badge" id="pairing-code-badge" style="display:none;">
                        <?php esc_html_e( 'أو استخدم كود الاقتران:', 'wox-whatsapp' ); ?> <strong id="wox-pairing-code"></strong>
                    </div>
                </div>
                <div id="connection-status-box" class="connection-status status-connecting">
                    <span class="dot"></span>
                    <span id="connection-status-text"><?php esc_html_e( 'بانتظار المسح...', 'wox-whatsapp' ); ?></span>
                </div>
            </div>

            <div class="wox-cta-row">
                <button type="button" class="wox-btn-secondary" id="btn-step-2-prev"><?php esc_html_e( 'السابق', 'wox-whatsapp' ); ?></button>
                <button type="button" class="wox-btn-primary" id="btn-step-2-next" disabled><?php esc_html_e( 'تم الربط! المتابعة ➜', 'wox-whatsapp' ); ?></button>
            </div>
            <div id="step-2-msg" class="wox-notice" style="display:none;"></div>
        </div>

        <!-- STEP 3: SELECT MODULES -->
        <div class="wox-step-pane" id="step-3" style="display:none;">
            <h3><?php esc_html_e( 'الخطوة 3: تحديد مجالات التكامل المطلوبة', 'wox-whatsapp' ); ?></h3>
            <p class="description"><?php esc_html_e( 'اختر الميزات والخدمات التي تريد تفعيلها في متجرك الآن:', 'wox-whatsapp' ); ?></p>

            <div class="wox-modules-grid">
                <!-- Module 1: WP Mail -->
                <div class="wox-module-card">
                    <div class="module-header">
                        <label class="wox-switch">
                            <input type="checkbox" id="mod_wp_mail" <?php checked( $enable_wp_mail, 'yes' ); ?> />
                            <span class="slider round"></span>
                        </label>
                        <h4>📨 <?php esc_html_e( 'تكامل بريد ووردبريس (WP Mail)', 'wox-whatsapp' ); ?></h4>
                    </div>
                    <p><?php esc_html_e( 'إرسال إشعارات النظام المهمة وروابط تعيين كلمة المرور عبر الواتساب كبديل أو مساند للبريد الإلكتروني.', 'wox-whatsapp' ); ?></p>
                </div>

                <!-- Module 2: WooCommerce Orders -->
                <div class="wox-module-card highlight">
                    <div class="module-header">
                        <label class="wox-switch">
                            <input type="checkbox" id="mod_woocommerce" <?php checked( $enable_wc, 'yes' ); ?> />
                            <span class="slider round"></span>
                        </label>
                        <h4>🛍️ <?php esc_html_e( 'تكامل ووكومرس وحالات الطلب', 'wox-whatsapp' ); ?></h4>
                    </div>
                    <p><?php esc_html_e( 'إشعار العملاء والمدير تلقائياً فور تغير حالة الطلب (قيد المعالجة، تم الشحن، ملغي، مكتمل) مع تفاصيل الفاتورة.', 'wox-whatsapp' ); ?></p>
                </div>

                <!-- Module 3: Abandoned Carts -->
                <div class="wox-module-card highlight">
                    <div class="module-header">
                        <label class="wox-switch">
                            <input type="checkbox" id="mod_abandoned_cart" <?php checked( $enable_cart, 'yes' ); ?> />
                            <span class="slider round"></span>
                        </label>
                        <h4>🛒 <?php esc_html_e( 'استرجاع السلات المتروكة', 'wox-whatsapp' ); ?></h4>
                    </div>
                    <p><?php esc_html_e( 'إرسال تذكيرات ذكية بنظام متتالي مع كود خصم ورابط استرجاع مباشر للعملاء الذين لم يكملوا الشراء.', 'wox-whatsapp' ); ?></p>
                </div>
            </div>

            <div class="wox-form-row" style="margin-top:20px;">
                <div class="wox-form-group half">
                    <label for="wox_admin_phone"><?php esc_html_e( 'رقم هاتف المدير (لتلقي التنبيهات)', 'wox-whatsapp' ); ?></label>
                    <input type="text" id="wox_admin_phone" class="wox-input" value="<?php echo esc_attr( $admin_phone ); ?>" placeholder="010XXXXXXXX or 2010XXXXXXXX" />
                </div>
                <div class="wox-form-group half">
                    <label for="wox_country_prefix"><?php esc_html_e( 'مفتاح الدولة الافتراضي', 'wox-whatsapp' ); ?></label>
                    <input type="text" id="wox_country_prefix" class="wox-input" value="<?php echo esc_attr( $country_prefix ); ?>" placeholder="+20 or +966" />
                </div>
            </div>

            <div class="wox-cta-row">
                <button type="button" class="wox-btn-secondary" id="btn-step-3-prev"><?php esc_html_e( 'السابق', 'wox-whatsapp' ); ?></button>
                <button type="button" class="wox-btn-primary" id="btn-step-3-next"><?php esc_html_e( 'حفظ والمتابعة ➜', 'wox-whatsapp' ); ?></button>
            </div>
            <div id="step-3-msg" class="wox-notice" style="display:none;"></div>
        </div>

        <!-- STEP 4: TEST & COMPLETE -->
        <div class="wox-step-pane" id="step-4" style="display:none;">
            <div class="wox-finish-box">
                <div class="finish-icon">🚀</div>
                <h3><?php esc_html_e( 'اكتملت التهيئة تقريباً! فلنجرب رسالة تجريبية', 'wox-whatsapp' ); ?></h3>
                <p><?php esc_html_e( 'أدخل رقم هاتفك لإرسال رسالة اختبار عبر الواتساب والتأكد من نجاح الربط.', 'wox-whatsapp' ); ?></p>

                <div class="wox-test-box">
                    <div class="wox-form-group">
                        <label for="test_phone"><?php esc_html_e( 'رقم الهاتف للتجربة:', 'wox-whatsapp' ); ?></label>
                        <input type="text" id="test_phone" class="wox-input" value="<?php echo esc_attr( $admin_phone ); ?>" placeholder="010XXXXXXXX" />
                    </div>
                    <button type="button" class="wox-btn-success" id="btn-send-test">
                        <?php esc_html_e( 'إرسال رسالة تجريبية الآن 📲', 'wox-whatsapp' ); ?>
                    </button>
                    <div id="test-msg-result" class="wox-notice" style="display:none;"></div>
                </div>

                <hr style="margin:30px 0; border:0; border-top:1px solid #e2e8f0;" />

                <div class="wox-cta-row center">
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=wox-dashboard' ) ); ?>" class="wox-btn-primary large">
                        <?php esc_html_e( 'الانتقال للوحة تحكم Wox الرئيسية 🎉', 'wox-whatsapp' ); ?>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
