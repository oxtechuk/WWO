<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>

<div class="wrap wox-admin-wrap">
    <h1>📋 <?php esc_html_e( 'سجل رسائل الواتساب الصادرة', 'wox-whatsapp' ); ?></h1>
    <p class="subtitle"><?php esc_html_e( 'تفاصيل تسليم الرسائل وحالات الإرسال والردود المستلمة من البوابة.', 'wox-whatsapp' ); ?></p>

    <div class="wox-table-section">
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th style="width:60px;">#</th>
                    <th style="width:140px;"><?php esc_html_e( 'المستلم', 'wox-whatsapp' ); ?></th>
                    <th style="width:130px;"><?php esc_html_e( 'النوع', 'wox-whatsapp' ); ?></th>
                    <th><?php esc_html_e( 'محتوى الرسالة', 'wox-whatsapp' ); ?></th>
                    <th style="width:100px;"><?php esc_html_e( 'الحالة', 'wox-whatsapp' ); ?></th>
                    <th style="width:150px;"><?php esc_html_e( 'التاريخ والوقت', 'wox-whatsapp' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if ( empty( $logs ) ) : ?>
                    <tr>
                        <td colspan="6" style="text-align:center; padding:30px;">
                            <?php esc_html_e( 'لا توجد رسائل مسجلة بعد في السجل.', 'wox-whatsapp' ); ?>
                        </td>
                    </tr>
                <?php else : ?>
                    <?php foreach ( $logs as $log ) :
                        $status_badge = ( $log->status === 'sent' ) ? 'badge-success' : ( ( $log->status === 'failed' ) ? 'badge-danger' : 'badge-neutral' );
                    ?>
                        <tr>
                            <td><?php echo intval( $log->id ); ?></td>
                            <td><strong><code><?php echo esc_html( $log->recipient ); ?></code></strong></td>
                            <td><span class="wox-pill"><?php echo esc_html( $log->message_type ); ?></span></td>
                            <td>
                                <div class="log-message-preview">
                                    <?php echo nl2br( esc_html( wp_trim_words( $log->content, 20, '...' ) ) ); ?>
                                </div>
                                <?php if ( ! empty( $log->error_message ) ) : ?>
                                    <small style="color:#ef4444;"><?php echo esc_html( $log->error_message ); ?></small>
                                <?php endif; ?>
                            </td>
                            <td><span class="wox-badge <?php echo esc_attr( $status_badge ); ?>"><?php echo esc_html( ucfirst( $log->status ) ); ?></span></td>
                            <td><small><?php echo esc_html( $log->created_at ); ?></small></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
