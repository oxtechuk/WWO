/* Wox Admin JavaScript */
jQuery(document).ready(function ($) {
    // Clicking on variable tags inserts them into focused or closest textarea
    $('.tags-cloud code').on('click', function () {
        var tag = $(this).text();
        var $activeTextarea = $('textarea:focus');
        if ($activeTextarea.length === 0) {
            $activeTextarea = $('textarea').first();
        }

        if ($activeTextarea.length > 0) {
            var el = $activeTextarea.get(0);
            var start = el.selectionStart;
            var end = el.selectionEnd;
            var val = el.value;
            el.value = val.substring(0, start) + tag + val.substring(end);
            el.selectionStart = el.selectionEnd = start + tag.length;
            $activeTextarea.focus();
        }
    });
});
