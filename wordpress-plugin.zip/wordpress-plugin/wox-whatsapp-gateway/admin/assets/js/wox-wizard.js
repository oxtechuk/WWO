/* Wox WhatsApp Setup Wizard JavaScript */
jQuery(document).ready(function ($) {
    var pollTimer = null;

    function goToStep(stepNumber) {
        $('.wox-step-pane').hide();
        $('#step-' + stepNumber).fadeIn(200);

        $('.step-item').removeClass('active');
        $('.step-item').each(function () {
            var s = parseInt($(this).data('step'));
            if (s === stepNumber) {
                $(this).addClass('active');
            } else if (s < stepNumber) {
                $(this).addClass('completed');
            }
        });
    }

    // Step 1: Verify Account & Subscription
    $('#btn-step-1-next').on('click', function () {
        var $btn = $(this);
        var accountId = $('#wox_account_id').val();
        var licenseKey = $('#wox_license_key').val();
        var serverUrl = $('#wox_server_url').val();
        var apiKey = $('#wox_api_key').val();
        var $notice = $('#step-1-msg');

        if (!accountId) {
            $notice.removeClass('success').addClass('error').text('يرجى إدخال معرف الحساب (Account ID)').show();
            return;
        }

        $btn.prop('disabled', true).text('جاري التحقق...');
        $notice.hide();

        $.post(wox_wizard_vars.ajax_url, {
            action: 'wox_wizard_verify_account',
            nonce: wox_wizard_vars.nonce,
            account_id: accountId,
            license_key: licenseKey,
            server_url: serverUrl,
            api_key: apiKey
        }, function (res) {
            $btn.prop('disabled', false).text('التحقق والمتابعة ➜');

            if (res.success) {
                $notice.removeClass('error').addClass('success').text(res.data.message).show();
                setTimeout(function () {
                    goToStep(2);
                    initWhatsAppInstance();
                }, 800);
            } else {
                $notice.removeClass('success').addClass('error').text(res.data.message || 'فشل التحقق').show();
            }
        }).fail(function () {
            $btn.prop('disabled', false).text('التحقق والمتابعة ➜');
            $notice.removeClass('success').addClass('error').text('حدث خطأ في الاتصال بالخادم').show();
        });
    });

    // Step 2: Init Instance and Polling QR
    function initWhatsAppInstance() {
        var instanceName = $('#wox_instance_name').val();
        $('#qr-loading').show();
        $('#qr-display').hide();
        $('#connection-status-box').removeClass('status-connected').addClass('status-connecting');
        $('#connection-status-text').text('جاري تهيئة الـ QR Code...');

        $.post(wox_wizard_vars.ajax_url, {
            action: 'wox_wizard_init_instance',
            nonce: wox_wizard_vars.nonce,
            instance_name: instanceName
        }, function (res) {
            $('#qr-loading').hide();

            if (res.success) {
                if (res.data.connected) {
                    onWhatsAppConnected();
                    return;
                }

                if (res.data.qrcode_base64) {
                    var src = res.data.qrcode_base64;
                    if (!src.startsWith('data:image')) {
                        src = 'data:image/png;base64,' + src;
                    }
                    $('#wox-qr-img').attr('src', src);
                    $('#qr-display').show();
                    $('#connection-status-text').text('امسح الكود عبر الواتساب في هاتفك...');

                    // Start polling
                    startStatusPolling();
                }
            } else {
                $('#step-2-msg').removeClass('success').addClass('error').text(res.data.message).show();
            }
        });
    }

    function startStatusPolling() {
        clearInterval(pollTimer);
        pollTimer = setInterval(function () {
            $.post(wox_wizard_vars.ajax_url, {
                action: 'wox_wizard_check_status',
                nonce: wox_wizard_vars.nonce
            }, function (res) {
                if (res.success && res.data.connected) {
                    clearInterval(pollTimer);
                    onWhatsAppConnected();
                }
            });
        }, 3000);
    }

    function onWhatsAppConnected() {
        $('#qr-loading').hide();
        $('#qr-display').hide();
        $('#connection-status-box').removeClass('status-connecting').addClass('status-connected');
        $('#connection-status-text').text('✅ تم اتصال الواتساب بنجاح!');
        $('#btn-step-2-next').prop('disabled', false);
        $('#step-2-msg').removeClass('error').addClass('success').text('تم ربط رقم الواتساب بنجاح. اضغط المتابعة.').show();
    }

    $('#btn-step-2-prev').on('click', function () {
        clearInterval(pollTimer);
        goToStep(1);
    });

    $('#btn-step-2-next').on('click', function () {
        clearInterval(pollTimer);
        goToStep(3);
    });

    // Step 3: Save Modules
    $('#btn-step-3-prev').on('click', function () {
        goToStep(2);
    });

    $('#btn-step-3-next').on('click', function () {
        var $btn = $(this);
        var enableWpMail = $('#mod_wp_mail').is(':checked') ? 'yes' : 'no';
        var enableWc = $('#mod_woocommerce').is(':checked') ? 'yes' : 'no';
        var enableCart = $('#mod_abandoned_cart').is(':checked') ? 'yes' : 'no';
        var adminPhone = $('#wox_admin_phone').val();
        var countryPrefix = $('#wox_country_prefix').val();

        $btn.prop('disabled', true).text('جاري الحفظ...');

        $.post(wox_wizard_vars.ajax_url, {
            action: 'wox_wizard_save_modules',
            nonce: wox_wizard_vars.nonce,
            enable_wp_mail: enableWpMail,
            enable_wc: enableWc,
            enable_cart: enableCart,
            admin_phone: adminPhone,
            country_prefix: countryPrefix
        }, function (res) {
            $btn.prop('disabled', false).text('حفظ والمتابعة ➜');
            if (res.success) {
                $('#test_phone').val(adminPhone);
                goToStep(4);
            }
        });
    });

    // Step 4: Send Test Message
    $('#btn-send-test').on('click', function () {
        var $btn = $(this);
        var phone = $('#test_phone').val();
        var $result = $('#test-msg-result');

        if (!phone) {
            $result.removeClass('success').addClass('error').text('يرجى إدخال رقم هاتف للاختبار').show();
            return;
        }

        $btn.prop('disabled', true).text('جاري الإرسال...');
        $result.hide();

        $.post(wox_wizard_vars.ajax_url, {
            action: 'wox_wizard_send_test',
            nonce: wox_wizard_vars.nonce,
            phone: phone
        }, function (res) {
            $btn.prop('disabled', false).text('إرسال رسالة تجريبية الآن 📲');
            if (res.success) {
                $result.removeClass('error').addClass('success').text(res.data.message).show();
            } else {
                $result.removeClass('success').addClass('error').text(res.data.message).show();
            }
        }).fail(function () {
            $btn.prop('disabled', false).text('إرسال رسالة تجريبية الآن 📲');
            $result.removeClass('success').addClass('error').text('فشل الاتصال').show();
        });
    });
});
