/* Wox Abandoned Cart - Checkout Listener */
(function ($) {
    'use strict';

    var debounceTimer = null;

    function captureCheckoutData() {
        var phone = $('#billing_phone').val();
        var email = $('#billing_email').val();
        var firstName = $('#billing_first_name').val() || '';
        var lastName = $('#billing_last_name').val() || '';
        var name = $.trim(firstName + ' ' + lastName);

        if (!phone || phone.length < 8) {
            return;
        }

        $.ajax({
            url: wox_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'wox_capture_checkout',
                nonce: wox_vars.nonce,
                phone: phone,
                email: email,
                name: name
            },
            success: function (res) {
                // Cart captured quietly
            }
        });
    }

    $(document).ready(function () {
        // Listen on input blur and change events
        $(document).on('blur change', '#billing_phone, #billing_email', function () {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(captureCheckoutData, 600);
        });
    });
})(jQuery);
