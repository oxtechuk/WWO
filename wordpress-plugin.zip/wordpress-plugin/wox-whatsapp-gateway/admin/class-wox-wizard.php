<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Wox_Wizard {

    private $api_client;

    public function __construct( Wox_API_Client $api_client ) {
        $this->api_client = $api_client;

        add_action( 'admin_init', array( $this, 'maybe_redirect_to_wizard' ) );
        add_action( 'admin_menu', array( $this, 'register_wizard_page' ) );

        // AJAX handlers for Wizard Steps
        add_action( 'wp_ajax_wox_wizard_verify_account', array( $this, 'ajax_verify_account' ) );
        add_action( 'wp_ajax_wox_wizard_init_instance', array( $this, 'ajax_init_instance' ) );
        add_action( 'wp_ajax_wox_wizard_check_status', array( $this, 'ajax_check_status' ) );
        add_action( 'wp_ajax_wox_wizard_save_modules', array( $this, 'ajax_save_modules' ) );
        add_action( 'wp_ajax_wox_wizard_send_test', array( $this, 'ajax_send_test' ) );
    }

    public function maybe_redirect_to_wizard() {
        if ( get_transient( 'wox_activation_redirect' ) ) {
            delete_transient( 'wox_activation_redirect' );

            if ( ! isset( $_GET['page'] ) || $_GET['page'] !== 'wox-setup-wizard' ) {
                wp_safe_redirect( admin_url( 'admin.php?page=wox-setup-wizard' ) );
                exit;
            }
        }
    }

    public function register_wizard_page() {
        add_submenu_page(
            null, // Hide from direct menu list, accessible via direct URL
            __( 'Wox Setup Wizard', 'wox-whatsapp' ),
            __( 'Setup Wizard', 'wox-whatsapp' ),
            'manage_options',
            'wox-setup-wizard',
            array( $this, 'render_wizard' )
        );
    }

    public function render_wizard() {
        // Enqueue styles and scripts
        wp_enqueue_style( 'wox-wizard-style', WOX_PLUGIN_URL . 'admin/assets/css/wox-wizard.css', array(), WOX_VERSION );
        wp_enqueue_script( 'wox-wizard-script', WOX_PLUGIN_URL . 'admin/assets/js/wox-wizard.js', array( 'jquery' ), WOX_VERSION, true );

        wp_localize_script( 'wox-wizard-script', 'wox_wizard_vars', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'wox_wizard_nonce' ),
            'strings'  => array(
                'connecting' => __( 'Connecting to WhatsApp...', 'wox-whatsapp' ),
                'connected'  => __( 'Connected Successfully!', 'wox-whatsapp' ),
                'failed'     => __( 'Connection Failed. Please try again.', 'wox-whatsapp' ),
                'testing'    => __( 'Sending test message...', 'wox-whatsapp' ),
            ),
        ) );

        include WOX_PLUGIN_DIR . 'admin/views/wizard.php';
    }

    /**
     * Step 1: Verify Account ID & License
     */
    public function ajax_verify_account() {
        check_ajax_referer( 'wox_wizard_nonce', 'nonce' );

        $account_id  = sanitize_text_field( $_POST['account_id'] ?? '' );
        $license_key = sanitize_text_field( $_POST['license_key'] ?? '' );
        $server_url  = esc_url_raw( $_POST['server_url'] ?? 'http://localhost:8080' );
        $api_key     = sanitize_text_field( $_POST['api_key'] ?? '' );

        if ( empty( $account_id ) ) {
            wp_send_json_error( array( 'message' => __( 'Please enter your Wox Account ID.', 'wox-whatsapp' ) ) );
        }

        // Verify with Central Platform
        $verification = $this->api_client->verify_license( $account_id, $license_key );

        if ( ! $verification['success'] ) {
            wp_send_json_error( array( 'message' => $verification['message'] ) );
        }

        // Save options
        update_option( 'wox_account_id', $account_id );
        update_option( 'wox_license_key', $license_key );
        update_option( 'wox_server_url', $server_url );
        update_option( 'wox_global_api_key', $api_key );
        update_option( 'wox_license_status', 'active' );
        update_option( 'wox_plan_type', $verification['plan'] ?? 'standard' );

        $this->api_client->refresh_config();

        wp_send_json_success( array(
            'message' => __( 'Account and subscription verified successfully!', 'wox-whatsapp' ),
            'plan'    => $verification['plan'] ?? 'standard',
        ) );
    }

    /**
     * Step 2: Init Instance and Fetch QR Code
     */
    public function ajax_init_instance() {
        check_ajax_referer( 'wox_wizard_nonce', 'nonce' );

        $instance_name = sanitize_text_field( $_POST['instance_name'] ?? '' );
        if ( empty( $instance_name ) ) {
            $instance_name = 'wox_store_' . wp_generate_password( 6, false );
        }

        update_option( 'wox_instance_name', $instance_name );
        $this->api_client->refresh_config();

        // 1. Create or ensure instance
        $create_res = $this->api_client->create_instance( $instance_name );

        // 2. Fetch QR Code
        $qr_res = $this->api_client->get_qr_code( $instance_name );

        if ( $qr_res['success'] && ! empty( $qr_res['base64'] ) ) {
            wp_send_json_success( array(
                'instance'     => $instance_name,
                'qrcode_base64' => $qr_res['base64'],
                'pairing_code' => $qr_res['pairing_code'] ?? '',
            ) );
        }

        // Fallback: If already connected, check state
        $state_res = $this->api_client->get_connection_state( $instance_name );
        if ( $state_res['state'] === 'open' ) {
            wp_send_json_success( array(
                'instance'  => $instance_name,
                'connected' => true,
                'message'   => __( 'Instance is already connected!', 'wox-whatsapp' ),
            ) );
        }

        wp_send_json_error( array(
            'message' => $qr_res['error'] ?? __( 'Could not generate QR Code. Make sure Wox Gateway is running.', 'wox-whatsapp' ),
        ) );
    }

    /**
     * Step 2.5: Polling WhatsApp connection state
     */
    public function ajax_check_status() {
        check_ajax_referer( 'wox_wizard_nonce', 'nonce' );

        $instance_name = get_option( 'wox_instance_name' );
        $state_res = $this->api_client->get_connection_state( $instance_name );

        wp_send_json_success( array(
            'state'     => $state_res['state'],
            'connected' => ( $state_res['state'] === 'open' ),
        ) );
    }

    /**
     * Step 3: Save Modules & Configurations
     */
    public function ajax_save_modules() {
        check_ajax_referer( 'wox_wizard_nonce', 'nonce' );

        $enable_wp_mail = sanitize_text_field( $_POST['enable_wp_mail'] ?? 'no' );
        $enable_wc      = sanitize_text_field( $_POST['enable_wc'] ?? 'no' );
        $enable_cart    = sanitize_text_field( $_POST['enable_cart'] ?? 'no' );
        $admin_phone    = sanitize_text_field( $_POST['admin_phone'] ?? '' );
        $country_prefix = sanitize_text_field( $_POST['country_prefix'] ?? '+20' );

        update_option( 'wox_enable_wp_mail', $enable_wp_mail );
        update_option( 'wox_enable_wc', $enable_wc );
        update_option( 'wox_enable_abandoned_cart', $enable_cart );
        update_option( 'wox_admin_phone', $admin_phone );
        update_option( 'wox_country_prefix', $country_prefix );
        update_option( 'wox_is_configured', true );

        wp_send_json_success( array(
            'message' => __( 'Configurations saved successfully!', 'wox-whatsapp' ),
        ) );
    }

    /**
     * Step 4: Send Test WhatsApp Message
     */
    public function ajax_send_test() {
        check_ajax_referer( 'wox_wizard_nonce', 'nonce' );

        $phone   = sanitize_text_field( $_POST['phone'] ?? '' );
        $message = sanitize_textarea_field( $_POST['message'] ?? '' );

        if ( empty( $phone ) ) {
            wp_send_json_error( array( 'message' => __( 'Please enter a test phone number.', 'wox-whatsapp' ) ) );
        }

        if ( empty( $message ) ) {
            $message = sprintf(
                __( "🎉 *مبروك! تم ربط إضافة Wox بنجاح.*\n\nمتجرك: %s\nنظام التنبيهات يعمل الآن بكفاءة عبر بوابة Wox WhatsApp Gateway.", 'wox-whatsapp' ),
                get_bloginfo( 'name' )
            );
        }

        $result = $this->api_client->send_text( $phone, $message );

        if ( ! empty( $result['success'] ) ) {
            wp_send_json_success( array(
                'message' => __( 'Test WhatsApp message sent successfully!', 'wox-whatsapp' ),
            ) );
        }

        wp_send_json_error( array(
            'message' => $result['error'] ?? __( 'Failed to send message. Please check connection.', 'wox-whatsapp' ),
        ) );
    }
}
