<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Wox_Admin {

    private $api_client;
    private $logger;

    public function __construct( Wox_API_Client $api_client, Wox_Logger $logger ) {
        $this->api_client = $api_client;
        $this->logger     = $logger;

        add_action( 'admin_menu', array( $this, 'register_admin_menus' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
    }

    public function register_admin_menus() {
        add_menu_page(
            __( 'Wox WhatsApp', 'wox-whatsapp' ),
            __( 'Wox WhatsApp', 'wox-whatsapp' ),
            'manage_options',
            'wox-dashboard',
            array( $this, 'render_dashboard' ),
            'dashicons-whatsapp',
            56
        );

        add_submenu_page(
            'wox-dashboard',
            __( 'Dashboard', 'wox-whatsapp' ),
            __( 'Dashboard', 'wox-whatsapp' ),
            'manage_options',
            'wox-dashboard',
            array( $this, 'render_dashboard' )
        );

        add_submenu_page(
            'wox-dashboard',
            __( 'General Settings', 'wox-whatsapp' ),
            __( 'Settings', 'wox-whatsapp' ),
            'manage_options',
            'wox-settings',
            array( $this, 'render_settings' )
        );

        if ( class_exists( 'WooCommerce' ) ) {
            add_submenu_page(
                'wox-dashboard',
                __( 'WooCommerce Notifications', 'wox-whatsapp' ),
                __( 'WooCommerce', 'wox-whatsapp' ),
                'manage_options',
                'wox-woocommerce',
                array( $this, 'render_woocommerce' )
            );

            add_submenu_page(
                'wox-dashboard',
                __( 'Abandoned Carts', 'wox-whatsapp' ),
                __( 'Abandoned Carts', 'wox-whatsapp' ),
                'manage_options',
                'wox-abandoned-carts',
                array( $this, 'render_abandoned_carts' )
            );
        }

        add_submenu_page(
            'wox-dashboard',
            __( 'Message Logs', 'wox-whatsapp' ),
            __( 'Logs', 'wox-whatsapp' ),
            'manage_options',
            'wox-logs',
            array( $this, 'render_logs' )
        );

        add_submenu_page(
            'wox-dashboard',
            __( 'Setup Wizard', 'wox-whatsapp' ),
            __( 'Setup Wizard', 'wox-whatsapp' ),
            'manage_options',
            'wox-setup-wizard',
            array( $this, 'redirect_to_wizard' )
        );
    }

    public function redirect_to_wizard() {
        // Handled by Wox_Wizard
    }

    public function register_settings() {
        register_setting( 'wox_settings_group', 'wox_server_url' );
        register_setting( 'wox_settings_group', 'wox_global_api_key' );
        register_setting( 'wox_settings_group', 'wox_instance_name' );
        register_setting( 'wox_settings_group', 'wox_account_id' );
        register_setting( 'wox_settings_group', 'wox_license_key' );
        register_setting( 'wox_settings_group', 'wox_admin_phone' );
        register_setting( 'wox_settings_group', 'wox_country_prefix' );
        register_setting( 'wox_settings_group', 'wox_enable_wp_mail' );
        register_setting( 'wox_settings_group', 'wox_wp_mail_mode' );

        // WC Settings
        register_setting( 'wox_wc_group', 'wox_enable_wc' );
        register_setting( 'wox_wc_group', 'wox_wc_notify_admin' );
        register_setting( 'wox_wc_group', 'wox_wc_status_pending' );
        register_setting( 'wox_wc_group', 'wox_wc_status_processing' );
        register_setting( 'wox_wc_group', 'wox_wc_status_on_hold' );
        register_setting( 'wox_wc_group', 'wox_wc_status_completed' );
        register_setting( 'wox_wc_group', 'wox_wc_status_cancelled' );
        register_setting( 'wox_wc_group', 'wox_wc_status_refunded' );
        // WC Templates
        register_setting( 'wox_wc_group', 'wox_tpl_wc_admin_new_order' );
        register_setting( 'wox_wc_group', 'wox_tpl_wc_status_pending' );
        register_setting( 'wox_wc_group', 'wox_tpl_wc_status_processing' );
        register_setting( 'wox_wc_group', 'wox_tpl_wc_status_on_hold' );
        register_setting( 'wox_wc_group', 'wox_tpl_wc_status_completed' );
        register_setting( 'wox_wc_group', 'wox_tpl_wc_status_cancelled' );
        register_setting( 'wox_wc_group', 'wox_tpl_wc_status_refunded' );

        // Abandoned Carts Settings
        register_setting( 'wox_cart_group', 'wox_enable_abandoned_cart' );
        register_setting( 'wox_cart_group', 'wox_cart_abandoned_cut_off' );
        register_setting( 'wox_cart_group', 'wox_cart_reminder_1_delay' );
        register_setting( 'wox_cart_group', 'wox_cart_reminder_2_delay' );
        register_setting( 'wox_cart_group', 'wox_cart_coupon_code' );
        register_setting( 'wox_cart_group', 'wox_tpl_cart_reminder_1' );
        register_setting( 'wox_cart_group', 'wox_tpl_cart_reminder_2' );
    }

    public function enqueue_admin_assets( $hook ) {
        if ( strpos( $hook, 'wox' ) === false ) {
            return;
        }

        wp_enqueue_style( 'wox-admin-css', WOX_PLUGIN_URL . 'admin/assets/css/wox-admin.css', array(), WOX_VERSION );
        wp_enqueue_script( 'wox-admin-js', WOX_PLUGIN_URL . 'admin/assets/js/wox-admin.js', array( 'jquery' ), WOX_VERSION, true );
    }

    public function render_dashboard() {
        $state = $this->api_client->get_connection_state();
        $stats = $this->logger->get_stats();
        include WOX_PLUGIN_DIR . 'admin/views/dashboard.php';
    }

    public function render_settings() {
        include WOX_PLUGIN_DIR . 'admin/views/settings.php';
    }

    public function render_woocommerce() {
        include WOX_PLUGIN_DIR . 'admin/views/woocommerce.php';
    }

    public function render_abandoned_carts() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wox_abandoned_carts';
        $carts = $wpdb->get_results( "SELECT * FROM {$table_name} ORDER BY id DESC LIMIT 50" );
        $total_abandoned = $wpdb->get_var( "SELECT COUNT(*) FROM {$table_name} WHERE status = 'abandoned'" );
        $total_recovered = $wpdb->get_var( "SELECT COUNT(*) FROM {$table_name} WHERE status = 'recovered'" );
        $recovered_revenue = $wpdb->get_var( "SELECT SUM(cart_total) FROM {$table_name} WHERE status = 'recovered'" ) ?? 0;
        include WOX_PLUGIN_DIR . 'admin/views/abandoned-cart.php';
    }

    public function render_logs() {
        $logs = $this->logger->get_recent_logs( 50 );
        include WOX_PLUGIN_DIR . 'admin/views/logs.php';
    }
}
