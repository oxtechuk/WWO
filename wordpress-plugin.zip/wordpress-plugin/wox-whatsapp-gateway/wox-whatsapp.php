<?php
/**
 * Plugin Name:       Wox WhatsApp Gateway
 * Plugin URI:        https://oxtech.com/wox
 * Description:       Enterprise WhatsApp Gateway integration for WordPress & WooCommerce by Ox Tech. Order notifications, abandoned cart recovery, live QR pairing, and wp_mail replacement.
 * Version:           1.0.0
 * Author:            Ox Tech
 * Author URI:        https://oxtech.com
 * License:           GPL-2.0+
 * Text Domain:       wox-whatsapp
 * Domain Path:       /languages
 * Requires at least: 5.6
 * Requires PHP:      7.4
 * WC requires at least: 4.0
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

define( 'WOX_VERSION', '1.0.0' );
define( 'WOX_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WOX_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WOX_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Autoloader / Includes for Core Classes
 */
require_once WOX_PLUGIN_DIR . 'includes/class-wox-activator.php';
require_once WOX_PLUGIN_DIR . 'includes/class-wox-deactivator.php';
require_once WOX_PLUGIN_DIR . 'includes/class-wox-api-client.php';
require_once WOX_PLUGIN_DIR . 'includes/class-wox-logger.php';
require_once WOX_PLUGIN_DIR . 'includes/class-wox-templates.php';
require_once WOX_PLUGIN_DIR . 'includes/class-wox-wp-mail.php';
require_once WOX_PLUGIN_DIR . 'includes/class-wox-woocommerce.php';
require_once WOX_PLUGIN_DIR . 'includes/class-wox-abandoned-cart.php';
require_once WOX_PLUGIN_DIR . 'admin/class-wox-admin.php';
require_once WOX_PLUGIN_DIR . 'admin/class-wox-wizard.php';

/**
 * The code that runs during plugin activation.
 */
function activate_wox_whatsapp() {
    Wox_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 */
function deactivate_wox_whatsapp() {
    Wox_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_wox_whatsapp' );
register_deactivation_hook( __FILE__, 'deactivate_wox_whatsapp' );

/**
 * Main Plugin Coordinator Class
 */
final class Wox_WhatsApp_Plugin {

    private static $instance = null;
    public $api_client;
    public $admin;
    public $wizard;
    public $wp_mail;
    public $woocommerce;
    public $abandoned_cart;
    public $logger;

    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init_components();
        $this->init_hooks();
    }

    private function init_components() {
        $this->logger         = new Wox_Logger();
        $this->api_client     = new Wox_API_Client();
        $this->admin          = new Wox_Admin( $this->api_client, $this->logger );
        $this->wizard         = new Wox_Wizard( $this->api_client );
        $this->wp_mail        = new Wox_WP_Mail( $this->api_client, $this->logger );
        $this->woocommerce    = new Wox_WooCommerce( $this->api_client, $this->logger );
        $this->abandoned_cart = new Wox_Abandoned_Cart( $this->api_client, $this->logger );
    }

    private function init_hooks() {
        add_action( 'init', array( $this, 'load_textdomain' ) );
        add_filter( 'plugin_action_links_' . WOX_PLUGIN_BASENAME, array( $this, 'add_action_links' ) );
    }

    public function load_textdomain() {
        load_plugin_textdomain(
            'wox-whatsapp',
            false,
            dirname( WOX_PLUGIN_BASENAME ) . '/languages/'
        );
    }

    public function add_action_links( $links ) {
        $custom_links = array(
            '<a href="' . esc_url( admin_url( 'admin.php?page=wox-settings' ) ) . '">' . esc_html__( 'Settings', 'wox-whatsapp' ) . '</a>',
            '<a href="' . esc_url( admin_url( 'admin.php?page=wox-setup-wizard' ) ) . '" style="color:#25d366;font-weight:600;">' . esc_html__( 'Setup Wizard', 'wox-whatsapp' ) . '</a>',
        );
        return array_merge( $custom_links, $links );
    }
}

/**
 * Bootstrap the plugin
 */
function wox_whatsapp() {
    return Wox_WhatsApp_Plugin::instance();
}

add_action( 'plugins_loaded', 'wox_whatsapp' );
