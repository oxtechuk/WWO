<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Wox_WooCommerce {

    private $api_client;
    private $logger;

    public function __construct( Wox_API_Client $api_client, Wox_Logger $logger ) {
        $this->api_client = $api_client;
        $this->logger     = $logger;

        if ( 'yes' === get_option( 'wox_enable_wc', 'yes' ) && class_exists( 'WooCommerce' ) ) {
            add_action( 'woocommerce_order_status_changed', array( $this, 'on_order_status_changed' ), 10, 4 );
            add_action( 'woocommerce_new_order', array( $this, 'on_new_order' ), 10, 2 );
        }
    }

    /**
     * Handle Admin Notification for New Orders
     */
    public function on_new_order( $order_id, $order = null ) {
        if ( 'yes' !== get_option( 'wox_wc_notify_admin', 'yes' ) ) {
            return;
        }

        $admin_phone = get_option( 'wox_admin_phone', '' );
        if ( empty( $admin_phone ) ) {
            return;
        }

        if ( ! $order ) {
            $order = wc_get_order( $order_id );
        }
        if ( ! $order ) {
            return;
        }

        $vars = $this->extract_order_variables( $order );
        $template = Wox_Templates::get_template( 'wc_admin_new_order' );
        $message  = Wox_Templates::render( $template, $vars );

        $log_id = $this->logger->log( $admin_phone, 'wc_admin_order', $message, 'pending' );
        $result = $this->api_client->send_text( $admin_phone, $message );

        if ( ! empty( $result['success'] ) ) {
            $this->logger->update_status( $log_id, 'sent', $result['code'] ?? 200 );
        } else {
            $this->logger->update_status( $log_id, 'failed', $result['code'] ?? 500, $result['error'] ?? '' );
        }
    }

    /**
     * Handle Customer Notification on Order Status Changes
     */
    public function on_order_status_changed( $order_id, $old_status, $new_status, $order ) {
        // Check if notifications for this status are enabled
        $option_key = 'wox_wc_status_' . $new_status;
        if ( 'yes' !== get_option( $option_key, 'yes' ) ) {
            return;
        }

        $customer_phone = $order->get_billing_phone();
        if ( empty( $customer_phone ) ) {
            return;
        }

        $template_key = 'wc_status_' . $new_status;
        $template = Wox_Templates::get_template( $template_key );
        if ( empty( $template ) ) {
            return;
        }

        $vars = $this->extract_order_variables( $order );
        $message = Wox_Templates::render( $template, $vars );

        $log_id = $this->logger->log( $customer_phone, 'wc_order_' . $new_status, $message, 'pending' );
        $result = $this->api_client->send_text( $customer_phone, $message );

        if ( ! empty( $result['success'] ) ) {
            $this->logger->update_status( $log_id, 'sent', $result['code'] ?? 200 );
            $order->add_order_note( sprintf( __( 'Wox WhatsApp: Notification sent for status [%s] to %s', 'wox-whatsapp' ), $new_status, $customer_phone ) );
        } else {
            $this->logger->update_status( $log_id, 'failed', $result['code'] ?? 500, $result['error'] ?? '' );
            $order->add_order_note( sprintf( __( 'Wox WhatsApp: Failed to send notification for [%s] to %s. Error: %s', 'wox-whatsapp' ), $new_status, $customer_phone, $result['error'] ?? 'Unknown' ) );
        }
    }

    /**
     * Extract placeholders from WC_Order
     */
    private function extract_order_variables( $order ) {
        $items_summary = array();
        foreach ( $order->get_items() as $item ) {
            $items_summary[] = '• ' . $item->get_name() . ' x ' . $item->get_quantity();
        }

        return array(
            '{order_id}'        => $order->get_id(),
            '{order_number}'    => $order->get_order_number(),
            '{order_status}'    => wc_get_order_status_name( $order->get_status() ),
            '{order_total}'     => html_entity_decode( wp_strip_all_tags( wc_price( $order->get_total(), array( 'currency' => $order->get_currency() ) ) ) ),
            '{customer_name}'   => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
            '{customer_phone}'  => $order->get_billing_phone(),
            '{customer_email}'  => $order->get_billing_email(),
            '{payment_method}'  => $order->get_payment_method_title(),
            '{shipping_address}'=> $order->get_formatted_shipping_address(),
            '{order_items}'     => implode( "\n", $items_summary ),
            '{admin_order_url}' => admin_url( 'post.php?post=' . $order->get_id() . '&action=edit' ),
            '{order_view_url}'  => $order->get_view_order_url(),
        );
    }
}
