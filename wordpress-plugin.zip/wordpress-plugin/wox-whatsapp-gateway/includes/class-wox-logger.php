<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Wox_Logger {

    public function log( $recipient, $type, $content, $status = 'pending', $code = null, $error = null ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wox_logs';

        $wpdb->insert(
            $table_name,
            array(
                'recipient'     => sanitize_text_field( $recipient ),
                'message_type'  => sanitize_text_field( $type ),
                'content'       => wp_kses_post( $content ),
                'status'        => sanitize_text_field( $status ),
                'response_code' => $code ? intval( $code ) : null,
                'error_message' => $error ? sanitize_text_field( $error ) : null,
                'created_at'    => current_time( 'mysql' ),
            ),
            array( '%s', '%s', '%s', '%s', '%d', '%s', '%s' )
        );

        return $wpdb->insert_id;
    }

    public function update_status( $log_id, $status, $code = null, $error = null ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wox_logs';

        $data = array( 'status' => sanitize_text_field( $status ) );
        $formats = array( '%s' );

        if ( ! is_null( $code ) ) {
            $data['response_code'] = intval( $code );
            $formats[] = '%d';
        }
        if ( ! is_null( $error ) ) {
            $data['error_message'] = sanitize_text_field( $error );
            $formats[] = '%s';
        }

        $wpdb->update(
            $table_name,
            $data,
            array( 'id' => intval( $log_id ) ),
            $formats,
            array( '%d' )
        );
    }

    public function get_recent_logs( $limit = 50, $offset = 0 ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wox_logs';
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table_name} ORDER BY id DESC LIMIT %d OFFSET %d",
                $limit,
                $offset
            )
        );
    }

    public function get_stats() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wox_logs';
        $total = $wpdb->get_var( "SELECT COUNT(*) FROM {$table_name}" );
        $sent  = $wpdb->get_var( "SELECT COUNT(*) FROM {$table_name} WHERE status = 'sent'" );
        $failed = $wpdb->get_var( "SELECT COUNT(*) FROM {$table_name} WHERE status = 'failed'" );

        return array(
            'total'  => intval( $total ),
            'sent'   => intval( $sent ),
            'failed' => intval( $failed ),
        );
    }
}
