<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Wox_Activator {

    public static function activate() {
        self::create_database_tables();
        self::set_default_options();

        // Trigger redirect to Setup Wizard
        set_transient( 'wox_activation_redirect', true, 60 );
    }

    private static function create_database_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // 1. Abandoned Carts Table
        $table_carts = $wpdb->prefix . 'wox_abandoned_carts';
        $sql_carts = "CREATE TABLE IF NOT EXISTS {$table_carts} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) DEFAULT 0,
            customer_name varchar(191) DEFAULT '',
            email varchar(191) DEFAULT '',
            phone varchar(50) NOT NULL,
            cart_contents longtext NOT NULL,
            cart_total decimal(10,2) NOT NULL DEFAULT '0.00',
            currency varchar(10) NOT NULL DEFAULT 'USD',
            status varchar(20) NOT NULL DEFAULT 'active',
            recovery_token varchar(64) NOT NULL,
            reminders_sent int(11) NOT NULL DEFAULT 0,
            last_reminder_at datetime DEFAULT NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY phone (phone),
            KEY status (status),
            KEY recovery_token (recovery_token)
        ) {$charset_collate};";
        dbDelta( $sql_carts );

        // 2. Message Delivery Logs Table
        $table_logs = $wpdb->prefix . 'wox_logs';
        $sql_logs = "CREATE TABLE IF NOT EXISTS {$table_logs} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            recipient varchar(50) NOT NULL,
            message_type varchar(50) NOT NULL DEFAULT 'general',
            content text NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'pending',
            response_code int(11) DEFAULT NULL,
            error_message text DEFAULT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY recipient (recipient),
            KEY status (status),
            KEY created_at (created_at)
        ) {$charset_collate};";
        dbDelta( $sql_logs );
    }

    private static function set_default_options() {
        $defaults = array(
            'wox_server_url'             => 'http://localhost:8080',
            'wox_global_api_key'         => '',
            'wox_instance_name'          => 'wox_store_' . wp_generate_password( 6, false ),
            'wox_account_id'             => '',
            'wox_license_key'            => '',
            'wox_license_status'         => 'inactive',
            'wox_plan_type'              => 'free',
            'wox_is_configured'          => false,
            // Modules
            'wox_enable_wp_mail'         => 'yes',
            'wox_admin_phone'            => '',
            'wox_country_prefix'         => '+20',
            'wox_wp_mail_mode'           => 'mirror', // 'replace' or 'mirror' (send both email and whatsapp)
            // WooCommerce
            'wox_enable_wc'              => 'yes',
            'wox_wc_notify_admin'        => 'yes',
            'wox_wc_status_pending'      => 'yes',
            'wox_wc_status_processing'   => 'yes',
            'wox_wc_status_completed'    => 'yes',
            'wox_wc_status_cancelled'    => 'yes',
            'wox_wc_status_refunded'     => 'yes',
            // Abandoned Cart
            'wox_enable_abandoned_cart'  => 'yes',
            'wox_cart_abandoned_cut_off' => 45, // minutes
            'wox_cart_reminder_1_delay'  => 60, // minutes
            'wox_cart_reminder_2_delay'  => 1440, // 24 hours
            'wox_cart_coupon_code'       => '',
        );

        foreach ( $defaults as $key => $val ) {
            if ( false === get_option( $key ) ) {
                add_option( $key, $val );
            }
        }
    }
}
