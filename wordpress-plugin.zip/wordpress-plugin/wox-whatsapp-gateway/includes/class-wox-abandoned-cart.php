<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Wox_Abandoned_Cart {

    private $api_client;
    private $logger;

    public function __construct( Wox_API_Client $api_client, Wox_Logger $logger ) {
        $this->api_client = $api_client;
        $this->logger     = $logger;

        if ( 'yes' === get_option( 'wox_enable_abandoned_cart', 'yes' ) && class_exists( 'WooCommerce' ) ) {
            // Frontend script for guest/user cart capture on checkout
            add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_checkout_scripts' ) );
            add_action( 'wp_ajax_wox_capture_checkout', array( $this, 'ajax_capture_checkout' ) );
            add_action( 'wp_ajax_nopriv_wox_capture_checkout', array( $this, 'ajax_capture_checkout' ) );

            // When order is successfully placed, recover the cart
            add_action( 'woocommerce_thankyou', array( $this, 'on_order_completed_recovery' ), 10, 1 );

            // Cron scheduling for checking abandoned carts
            add_action( 'wox_cron_abandoned_cart_check', array( $this, 'process_abandoned_carts' ) );
            if ( ! wp_next_scheduled( 'wox_cron_abandoned_cart_check' ) ) {
                wp_schedule_event( time(), 'hourly', 'wox_cron_abandoned_cart_check' );
            }

            // Restore cart on recovery URL visit
            add_action( 'template_redirect', array( $this, 'handle_cart_recovery_link' ) );
        }
    }

    public function enqueue_checkout_scripts() {
        if ( is_checkout() && ! is_order_received_page() ) {
            wp_enqueue_script(
                'wox-checkout-capture',
                WOX_PLUGIN_URL . 'admin/assets/js/wox-checkout.js',
                array( 'jquery' ),
                WOX_VERSION,
                true
            );

            wp_localize_script( 'wox-checkout-capture', 'wox_vars', array(
                'ajax_url' => admin_url( 'admin-ajax.php' ),
                'nonce'    => wp_create_nonce( 'wox_cart_nonce' ),
            ) );
        }
    }

    /**
     * AJAX handler to save or update active checkout cart
     */
    public function ajax_capture_checkout() {
        check_ajax_referer( 'wox_cart_nonce', 'nonce' );

        $phone = sanitize_text_field( $_POST['phone'] ?? '' );
        $email = sanitize_email( $_POST['email'] ?? '' );
        $name  = sanitize_text_field( $_POST['name'] ?? '' );

        if ( empty( $phone ) || ! WC()->cart || WC()->cart->is_empty() ) {
            wp_send_json_error( array( 'message' => 'Empty phone or cart' ) );
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'wox_abandoned_carts';

        $cart_contents = WC()->cart->get_cart();
        $cart_total    = WC()->cart->get_total( 'edit' );
        $currency      = get_woocommerce_currency();
        $user_id       = get_current_user_id();

        // Check if there's already an active cart for this phone
        $existing = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE phone = %s AND status = 'active' LIMIT 1",
            $phone
        ) );

        if ( $existing ) {
            $wpdb->update(
                $table_name,
                array(
                    'customer_name' => ! empty( $name ) ? $name : $existing->customer_name,
                    'email'         => ! empty( $email ) ? $email : $existing->email,
                    'cart_contents' => maybe_serialize( $cart_contents ),
                    'cart_total'    => $cart_total,
                    'updated_at'    => current_time( 'mysql' ),
                ),
                array( 'id' => $existing->id ),
                array( '%s', '%s', '%s', '%f', '%s' ),
                array( '%d' )
            );
        } else {
            $recovery_token = wp_generate_password( 32, false );
            $wpdb->insert(
                $table_name,
                array(
                    'user_id'        => $user_id,
                    'customer_name'  => $name,
                    'email'          => $email,
                    'phone'          => $phone,
                    'cart_contents'  => maybe_serialize( $cart_contents ),
                    'cart_total'     => $cart_total,
                    'currency'       => $currency,
                    'status'         => 'active',
                    'recovery_token' => $recovery_token,
                    'reminders_sent' => 0,
                    'created_at'     => current_time( 'mysql' ),
                    'updated_at'     => current_time( 'mysql' ),
                ),
                array( '%d', '%s', '%s', '%s', '%s', '%f', '%s', '%s', '%s', '%d', '%s', '%s' )
            );
        }

        wp_send_json_success();
    }

    /**
     * Mark cart as recovered when checkout completes
     */
    public function on_order_completed_recovery( $order_id ) {
        if ( ! $order_id ) {
            return;
        }

        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            return;
        }

        $phone = $order->get_billing_phone();
        if ( empty( $phone ) ) {
            return;
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'wox_abandoned_carts';

        $wpdb->update(
            $table_name,
            array( 'status' => 'recovered', 'updated_at' => current_time( 'mysql' ) ),
            array( 'phone' => $phone, 'status' => 'abandoned' ),
            array( '%s', '%s' ),
            array( '%s', '%s' )
        );

        $wpdb->update(
            $table_name,
            array( 'status' => 'recovered', 'updated_at' => current_time( 'mysql' ) ),
            array( 'phone' => $phone, 'status' => 'active' ),
            array( '%s', '%s' ),
            array( '%s', '%s' )
        );
    }

    /**
     * Process Abandoned Carts and Send WhatsApp Reminders
     */
    public function process_abandoned_carts() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wox_abandoned_carts';

        $cut_off_minutes = intval( get_option( 'wox_cart_abandoned_cut_off', 45 ) );
        $reminder_1_delay = intval( get_option( 'wox_cart_reminder_1_delay', 60 ) );
        $reminder_2_delay = intval( get_option( 'wox_cart_reminder_2_delay', 1440 ) );
        $coupon_code      = get_option( 'wox_cart_coupon_code', 'SAVE10' );

        $cut_off_time = gmdate( 'Y-m-d H:i:s', time() - ( $cut_off_minutes * 60 ) );

        // 1. Mark active carts older than cut-off as 'abandoned'
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$table_name} SET status = 'abandoned' WHERE status = 'active' AND updated_at <= %s",
            $cut_off_time
        ) );

        // 2. Fetch abandoned carts eligible for reminders
        $abandoned_carts = $wpdb->get_results(
            "SELECT * FROM {$table_name} WHERE status = 'abandoned' AND reminders_sent < 2 ORDER BY id ASC LIMIT 25"
        );

        foreach ( $abandoned_carts as $cart ) {
            $now = time();
            $updated = strtotime( $cart->updated_at );
            $reminders_sent = intval( $cart->reminders_sent );

            $should_send_rem1 = ( $reminders_sent === 0 && ( $now - $updated ) >= ( $reminder_1_delay * 60 ) );
            $should_send_rem2 = ( $reminders_sent === 1 && ( $now - $updated ) >= ( $reminder_2_delay * 60 ) );

            if ( $should_send_rem1 || $should_send_rem2 ) {
                $recovery_url = add_query_arg( 'wox_recover', $cart->recovery_token, wc_get_cart_url() );
                $items_list = $this->format_cart_items( maybe_unserialize( $cart->cart_contents ) );

                $vars = array(
                    '{customer_name}' => ! empty( $cart->customer_name ) ? $cart->customer_name : __( 'Customer', 'wox-whatsapp' ),
                    '{cart_total}'    => wc_price( $cart->cart_total, array( 'currency' => $cart->currency ) ),
                    '{cart_items}'    => $items_list,
                    '{cart_url}'      => $recovery_url,
                    '{coupon_code}'   => $coupon_code,
                );

                $template_key = ( $reminders_sent === 0 ) ? 'cart_reminder_1' : 'cart_reminder_2';
                $template     = Wox_Templates::get_template( $template_key );
                $message      = Wox_Templates::render( $template, $vars );

                $log_id = $this->logger->log( $cart->phone, 'cart_reminder_' . ( $reminders_sent + 1 ), $message, 'pending' );
                $result = $this->api_client->send_text( $cart->phone, $message );

                if ( ! empty( $result['success'] ) ) {
                    $this->logger->update_status( $log_id, 'sent', $result['code'] ?? 200 );
                    $wpdb->update(
                        $table_name,
                        array(
                            'reminders_sent'   => $reminders_sent + 1,
                            'last_reminder_at' => current_time( 'mysql' ),
                        ),
                        array( 'id' => $cart->id ),
                        array( '%d', '%s' ),
                        array( '%d' )
                    );
                } else {
                    $this->logger->update_status( $log_id, 'failed', $result['code'] ?? 500, $result['error'] ?? '' );
                }
            }
        }
    }

    private function format_cart_items( $items ) {
        if ( ! is_array( $items ) ) {
            return '';
        }
        $formatted = array();
        foreach ( $items as $item ) {
            $product_id = $item['product_id'] ?? 0;
            $product = wc_get_product( $product_id );
            if ( $product ) {
                $formatted[] = '• ' . $product->get_name() . ' (x' . ( $item['quantity'] ?? 1 ) . ')';
            }
        }
        return implode( "\n", $formatted );
    }

    /**
     * Restore cart session when customer clicks recovery link
     */
    public function handle_cart_recovery_link() {
        if ( isset( $_GET['wox_recover'] ) && ! empty( $_GET['wox_recover'] ) ) {
            $token = sanitize_text_field( $_GET['wox_recover'] );
            global $wpdb;
            $table_name = $wpdb->prefix . 'wox_abandoned_carts';

            $cart = $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM {$table_name} WHERE recovery_token = %s LIMIT 1",
                $token
            ) );

            if ( $cart && WC()->cart ) {
                if ( WC()->cart->is_empty() ) {
                    $contents = maybe_unserialize( $cart->cart_contents );
                    if ( is_array( $contents ) ) {
                        foreach ( $contents as $item ) {
                            WC()->cart->add_to_cart(
                                $item['product_id'],
                                $item['quantity'],
                                $item['variation_id'] ?? 0,
                                $item['variation'] ?? array()
                            );
                        }
                    }
                }
                wc_add_notice( __( 'Welcome back! We have restored your cart items.', 'wox-whatsapp' ), 'success' );
            }
        }
    }
}
