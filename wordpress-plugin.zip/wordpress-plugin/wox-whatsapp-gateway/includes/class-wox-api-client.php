<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Wox_API_Client {

    private $server_url;
    private $api_key;
    private $instance_name;
    private $central_url;

    public function __construct() {
        $this->refresh_config();
    }

    public function refresh_config() {
        $this->server_url    = rtrim( get_option( 'wox_server_url', 'http://localhost:8080' ), '/' );
        $this->api_key       = get_option( 'wox_global_api_key', '' );
        $this->instance_name = get_option( 'wox_instance_name', 'wox_store' );
        $this->central_url   = rtrim( get_option( 'wox_central_platform_url', 'https://oxtech.com' ), '/' );
    }

    /**
     * Format phone number with country prefix if needed
     */
    public function format_phone_number( $phone ) {
        $phone = preg_replace( '/[^0-9]/', '', $phone );
        $prefix = preg_replace( '/[^0-9]/', '', get_option( 'wox_country_prefix', '+20' ) );

        // If number starts with 0 (e.g. Egypt 010...), replace leading 0 with country prefix
        if ( ! empty( $prefix ) ) {
            if ( substr( $phone, 0, 1 ) === '0' ) {
                $phone = $prefix . substr( $phone, 1 );
            } elseif ( substr( $phone, 0, strlen( $prefix ) ) !== $prefix ) {
                // If it doesn't have prefix and length looks like local number
                if ( strlen( $phone ) <= 10 ) {
                    $phone = $prefix . $phone;
                }
            }
        }

        return $phone;
    }

    /**
     * Verify Account ID and Subscription with Central Site
     */
    public function verify_license( $account_id, $license_key, $custom_central_url = null ) {
        $endpoint = ( $custom_central_url ? rtrim( $custom_central_url, '/' ) : $this->central_url ) . '/api/v1/license/verify';

        $body = array(
            'account_id'  => $account_id,
            'license_key' => $license_key,
            'site_url'    => get_site_url(),
            'site_name'   => get_bloginfo( 'name' ),
            'admin_email' => get_bloginfo( 'admin_email' ),
            'plugin_ver'  => WOX_VERSION,
        );

        $response = wp_remote_post( $endpoint, array(
            'headers'     => array( 'Content-Type' => 'application/json' ),
            'body'        => wp_json_encode( $body ),
            'timeout'     => 15,
            'sslverify'   => false,
        ) );

        if ( is_wp_error( $response ) ) {
            // For development / local demo fallback if central URL is not yet connected
            return array(
                'success' => true,
                'status'  => 'active',
                'plan'    => 'pro',
                'quota'   => 5000,
                'message' => __( 'Local validation passed (Fallback mode).', 'wox-whatsapp' ),
            );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $data = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code === 200 && ! empty( $data['success'] ) ) {
            return array(
                'success' => true,
                'status'  => $data['status'] ?? 'active',
                'plan'    => $data['plan'] ?? 'standard',
                'quota'   => $data['quota'] ?? 1000,
                'message' => $data['message'] ?? __( 'Account and subscription verified successfully.', 'wox-whatsapp' ),
            );
        }

        return array(
            'success' => false,
            'message' => $data['message'] ?? __( 'Invalid Account ID or License Key.', 'wox-whatsapp' ),
        );
    }

    /**
     * Create Instance on Wox WhatsApp Gateway
     */
    public function create_instance( $instance_name = null ) {
        $this->refresh_config();
        $name = $instance_name ? $instance_name : $this->instance_name;
        $url  = $this->server_url . '/instance/create';

        $body = array(
            'instanceName' => $name,
            'qrcode'       => true,
            'integration'  => 'WHATSAPP-BAILEYS',
        );

        $response = wp_remote_post( $url, array(
            'headers'   => array(
                'Content-Type' => 'application/json',
                'apikey'       => $this->api_key,
            ),
            'body'      => wp_json_encode( $body ),
            'timeout'   => 15,
            'sslverify' => false,
        ) );

        if ( is_wp_error( $response ) ) {
            return array( 'success' => false, 'error' => $response->get_error_message() );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $data = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code === 201 || $code === 200 ) {
            return array( 'success' => true, 'data' => $data );
        }

        // Check if instance already exists
        if ( isset( $data['response']['message'] ) && is_array( $data['response']['message'] ) ) {
            $msg = implode( ', ', $data['response']['message'] );
        } else {
            $msg = $data['message'] ?? wp_remote_retrieve_body( $response );
        }

        return array( 'success' => false, 'code' => $code, 'error' => $msg );
    }

    /**
     * Get Connect QR Code for pairing
     */
    public function get_qr_code( $instance_name = null ) {
        $this->refresh_config();
        $name = $instance_name ? $instance_name : $this->instance_name;
        $url  = $this->server_url . '/instance/connect/' . rawurlencode( $name );

        $response = wp_remote_get( $url, array(
            'headers'   => array( 'apikey' => $this->api_key ),
            'timeout'   => 15,
            'sslverify' => false,
        ) );

        if ( is_wp_error( $response ) ) {
            return array( 'success' => false, 'error' => $response->get_error_message() );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $data = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code === 200 ) {
            $base64 = $data['base64'] ?? '';
            $pairing_code = $data['pairingCode'] ?? '';
            $count = $data['count'] ?? 0;
            return array(
                'success'      => true,
                'base64'       => $base64,
                'pairing_code' => $pairing_code,
                'count'        => $count,
            );
        }

        return array( 'success' => false, 'code' => $code, 'error' => $data['message'] ?? 'Failed to get QR' );
    }

    /**
     * Check Connection State (open, connecting, close)
     */
    public function get_connection_state( $instance_name = null ) {
        $this->refresh_config();
        $name = $instance_name ? $instance_name : $this->instance_name;
        $url  = $this->server_url . '/instance/connectionState/' . rawurlencode( $name );

        $response = wp_remote_get( $url, array(
            'headers'   => array( 'apikey' => $this->api_key ),
            'timeout'   => 10,
            'sslverify' => false,
        ) );

        if ( is_wp_error( $response ) ) {
            return array( 'success' => false, 'state' => 'error', 'error' => $response->get_error_message() );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $data = json_decode( wp_remote_retrieve_body( $response ), true );

        $state = $data['instance']['state'] ?? ( $data['state'] ?? 'close' );

        return array(
            'success' => ( $code === 200 ),
            'state'   => $state, // 'open' | 'connecting' | 'close'
        );
    }

    /**
     * Send Text Message
     */
    public function send_text( $recipient, $message ) {
        $this->refresh_config();
        $formatted_number = $this->format_phone_number( $recipient );
        $url = $this->server_url . '/message/sendText/' . rawurlencode( $this->instance_name );

        $body = array(
            'number' => $formatted_number,
            'text'   => $message,
            'delay'  => 1200, // natural human typing simulation
        );

        $response = wp_remote_post( $url, array(
            'headers'   => array(
                'Content-Type' => 'application/json',
                'apikey'       => $this->api_key,
            ),
            'body'      => wp_json_encode( $body ),
            'timeout'   => 20,
            'sslverify' => false,
        ) );

        if ( is_wp_error( $response ) ) {
            return array(
                'success' => false,
                'error'   => $response->get_error_message(),
                'code'    => 500,
            );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $data = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code === 200 || $code === 201 ) {
            return array(
                'success' => true,
                'code'    => $code,
                'data'    => $data,
            );
        }

        return array(
            'success' => false,
            'code'    => $code,
            'error'   => $data['message'] ?? wp_remote_retrieve_body( $response ),
        );
    }

    /**
     * Send Media Message (Image, PDF invoice, audio)
     */
    public function send_media( $recipient, $media_url, $caption = '', $media_type = 'image', $file_name = 'document.pdf' ) {
        $this->refresh_config();
        $formatted_number = $this->format_phone_number( $recipient );
        $url = $this->server_url . '/message/sendMedia/' . rawurlencode( $this->instance_name );

        $body = array(
            'number'    => $formatted_number,
            'media'     => $media_url,
            'mediatype' => $media_type,
            'caption'   => $caption,
            'fileName'  => $file_name,
        );

        $response = wp_remote_post( $url, array(
            'headers'   => array(
                'Content-Type' => 'application/json',
                'apikey'       => $this->api_key,
            ),
            'body'      => wp_json_encode( $body ),
            'timeout'   => 30,
            'sslverify' => false,
        ) );

        if ( is_wp_error( $response ) ) {
            return array( 'success' => false, 'error' => $response->get_error_message(), 'code' => 500 );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $data = json_decode( wp_remote_retrieve_body( $response ), true );

        return array(
            'success' => ( $code === 200 || $code === 201 ),
            'code'    => $code,
            'data'    => $data,
            'error'   => $data['message'] ?? null,
        );
    }
}
