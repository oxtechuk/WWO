<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Wox_Deactivator {

    public static function deactivate() {
        // Clear scheduled crons
        wp_clear_scheduled_hook( 'wox_cron_abandoned_cart_check' );
        wp_clear_scheduled_hook( 'wox_cron_license_sync' );
    }
}
