<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Wox_Templates {

    public static function get_default_template( $key ) {
        $templates = array(
            // Admin Notification
            'wc_admin_new_order' => "🔔 *طلب جديد في متجر {site_name}*\n\nرقم الطلب: #{order_id}\nالعميل: {customer_name}\nالهاتف: {customer_phone}\nالإجمالي: {order_total}\nطريقة الدفع: {payment_method}\n\nالمنتجات:\n{order_items}\n\nرابط الطلب:\n{admin_order_url}",
            
            // Customer Order Statuses
            'wc_status_pending' => "مرحباً {customer_name} 👋\n\nتم استلام طلبك رقم *#{order_id}* بنجاح في متجر {site_name} وهو الآن بانتظار الدفع أو التأكيد.\n\nالإجمالي: {order_total}\nشكراً لتسوقك معنا!",
            'wc_status_processing' => "مرحباً {customer_name} 👋\n\nطلبك رقم *#{order_id}* قيد التجهيز الآن في متجر {site_name} 📦.\nسنقوم بإعلامك فور شحن الطلب إليك.\n\nالإجمالي: {order_total}\nشكراً لثقتك بنا!",
            'wc_status_on_hold' => "مرحباً {customer_name} 👋\n\nطلبك رقم *#{order_id}* معلق حالياً في متجر {site_name} بانتظار مراجعة الدفع.\nسنتواصل معك في حال احتجنا أي معلومات إضافية.",
            'wc_status_completed' => "مرحباً {customer_name} 🎉\n\nيسعدنا إخبارك بأن طلبك رقم *#{order_id}* قد اكتمل وتم تسليمه بنجاح!\n\nنتمنى لك تجربة ممتعة ونسعد بخدمتك دائماً في متجر {site_name} ❤️.",
            'wc_status_cancelled' => "مرحباً {customer_name}\n\nنود إبلاغك بأنه قد تم إلغاء طلبك رقم *#{order_id}* في متجر {site_name}.\nإذا كان هذا تم بالخطأ أو لديك أي استفسار، يرجى التواصل معنا.",
            'wc_status_refunded' => "مرحباً {customer_name}\n\nتم استرجاع مبلغ طلبك رقم *#{order_id}* بمبلغ {order_total} من متجر {site_name}.\nنتطلع لخدمتك مرة أخرى في المستقبل.",
            
            // Abandoned Cart Reminders
            'cart_reminder_1' => "مرحباً {customer_name} 👋\n\nلاحظنا أنك تركت بعض المنتجات الرائعة في سلتك في متجر {site_name} 🛒:\n{cart_items}\n\nهل واجهتك أي مشكلة أثناء إتمام الطلب؟ يمكنك استكمال طلبك بسهولة بنقرة واحدة عبر الرابط:\n{cart_url}",
            'cart_reminder_2' => "مرحباً {customer_name} 🎁\n\nسلتك ما زالت بانتظارك في {site_name}!\nلإسعادك، خصصنا لك كود خصم خاص: *{coupon_code}*\n\nاستخدم الرابط التالي لإتمام الشراء بالخصم قبل نفاد الكمية:\n{cart_url}",
            
            // WP Mail / System Notifications
            'wp_mail_admin' => "⚠️ *تنبيه نظام من ووردبريس - {site_name}*\n\n*الموضوع:* {subject}\n\n*الرسالة:*\n{message}",
            'wp_mail_password_reset' => "مرحباً {user_login} 🔐\n\nتم طلب رابط لإعادة تعيين كلمة المرور الخاصة بحسابك في {site_name}.\n\nإذا كنت من طلب ذلك، يمكنك التعيين عبر الرابط:\n{reset_url}\n\nإذا لم تكن أنت، يرجى تجاهل هذه الرسالة.",
        );

        return $templates[ $key ] ?? '';
    }

    public static function get_template( $key ) {
        $custom = get_option( 'wox_tpl_' . $key );
        if ( ! empty( $custom ) ) {
            return $custom;
        }
        return self::get_default_template( $key );
    }

    public static function render( $template, $variables = array() ) {
        $default_vars = array(
            '{site_name}' => get_bloginfo( 'name' ),
            '{site_url}'  => get_site_url(),
        );

        $merged = array_merge( $default_vars, $variables );

        return str_replace( array_keys( $merged ), array_values( $merged ), $template );
    }
}
