<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Wox_WP_Mail {

    private $api_client;
    private $logger;

    public function __construct( Wox_API_Client $api_client, Wox_Logger $logger ) {
        $this->api_client = $api_client;
        $this->logger     = $logger;

        if ( get_option( 'wox_enable_wp_mail', 'yes' ) === 'yes' ) {
            add_filter( 'wp_mail', array( $this, 'intercept_wp_mail' ), 999 );
        }
    }

    public function intercept_wp_mail( $args ) {
        $mode = get_option( 'wox_wp_mail_mode', 'mirror' );
        $admin_phone = get_option( 'wox_admin_phone', '' );
        $admin_email = get_option( 'admin_email' );

        $to      = is_array( $args['to'] ) ? implode( ',', $args['to'] ) : $args['to'];
        $subject = $args['subject'];
        $message = wp_strip_all_tags( $args['message'] );

        // 1. Check if email is destined for the site admin
        if ( strpos( $to, $admin_email ) !== false && ! empty( $admin_phone ) ) {
            $formatted_msg = Wox_Templates::render(
                Wox_Templates::get_template( 'wp_mail_admin' ),
                array(
                    '{subject}' => $subject,
                    '{message}' => $message,
                )
            );

            $this->send_notification( $admin_phone, 'wp_mail_admin', $formatted_msg );
        }

        // 2. Check if this is a password reset email for a user
        if ( false !== stripos( $subject, 'Password Reset' ) || false !== stripos( $subject, 'إعادة تعيين كلمة المرور' ) ) {
            $user = get_user_by( 'email', $to );
            if ( $user ) {
                $user_phone = get_user_meta( $user->ID, 'billing_phone', true );
                if ( empty( $user_phone ) ) {
                    $user_phone = get_user_meta( $user->ID, 'phone', true );
                }

                if ( ! empty( $user_phone ) ) {
                    // Extract reset URL if present
                    preg_match( '/https?:\/\/[^\s]+/', $message, $matches );
                    $reset_url = $matches[0] ?? '';

                    $formatted_msg = Wox_Templates::render(
                        Wox_Templates::get_template( 'wp_mail_password_reset' ),
                        array(
                            '{user_login}' => $user->user_login,
                            '{reset_url}'   => $reset_url,
                        )
                    );

                    $this->send_notification( $user_phone, 'wp_mail_pwd_reset', $formatted_msg );
                }
            }
        }

        // If mode is replace, prevent actual mail from sending by emptying recipient
        if ( $mode === 'replace' ) {
            // Returning empty recipients prevents PHPMailer from sending standard email
            $args['to'] = array();
        }

        return $args;
    }

    private function send_notification( $recipient, $type, $content ) {
        $log_id = $this->logger->log( $recipient, $type, $content, 'pending' );
        $result = $this->api_client->send_text( $recipient, $content );

        if ( ! empty( $result['success'] ) ) {
            $this->logger->update_status( $log_id, 'sent', $result['code'] ?? 200 );
        } else {
            $this->logger->update_status( $log_id, 'failed', $result['code'] ?? 500, $result['error'] ?? 'Unknown Error' );
        }
    }
}
